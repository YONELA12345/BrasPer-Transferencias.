var ccerrar=document.querySelector('.popup');
                var btncerrar=document.getElementById('btn-cerrar');
                btncerrar.addEventListener('click',function(){
                    ccerrar.classList.toggle('ocultar');
                });