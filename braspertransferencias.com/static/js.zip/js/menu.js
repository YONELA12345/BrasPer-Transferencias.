let btnmenu=document.getElementById("btnmenu");
let contxtmenu=document.getElementById("contxtmenu");
btnmenu.addEventListener('click',function(){
    contxtmenu.classList.toggle('mostrar');
});