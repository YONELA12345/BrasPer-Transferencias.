
function invita(){
    
    //var url = 'https://ejemplo.com/enviar?codpais=' + encodeURIComponent(codpais) + '&numw=' + encodeURIComponent(numw);
    //var url='https://api.whatsapp.com/send/?phone='+ encodeURIComponent(codpais) + encodeURIComponent(numw)+ '&text= Hola,+estas+a+un+paso+de+comenzar+una+nueva+experiencia+con+tus+env%C3%ADos+online+a+Perú+y+Brasil+ven+con+nosotros+y+sé+parte+de+la+comunidad+de+Brasper+Transferencias+Confianza,+seguridad+y+rapidez+en+sus+env%C3%ADos+&type=phone_number&app_absent=0'
    //var url='https://wa.me/?text=Hola,%20estas%20a%20un%20paso%20de%20comenzar%20una%20nueva%20experiencia%20con%20tus%20env%C3%ADos%20online%20a%20Per%C3%BA%20PE%20y%20Brasil%20BR%20.%20Ven%20con%20nosotros%20y%20se%20parte%20de%20la%20comunidad%20de%20Brasper%20Transferencias%20!%20%F0%9F%98%8E%20.%20Confianza%20,%20seguridad%20y%20rapidez%20en%20sus%20env%C3%ADo%20%E2%9D%A4%EF%B8%8F%20%F0%9F%92%9A%20%F0%9F%8E%89%20%F0%9F%91%87%20%F0%9F%92%9A%20.%20Haga%20click%20en%20el%20siguiente%20enlace%20%F0%9F%98%8A%20https://rb.gy/vjpce3%20`'
    //var url='https://wa.me/?text=Hola,%20estas%20a%20un%20paso%20de%20comenzar%20una%20nueva%20experiencia%20con%20tus%20Envíos%20Online%20a%20Brasil%20BR%20y%20Perú%20PE%20.%20.%20.%20Ven%20con%20nosotros%20y%20se%20parte%20de%20la%20comunidad%20de%20Brasper%20Transferencias%20https://rb.gy/vjpce3'
    //var url='https://wa.me/?text=*Hola,%20estas%20a%20un%20paso%20de%20comenzar%20una%20nueva%20experiencia%20con%20tus%20Envíos%20Online%20a%20Brasil%20BR%20y%20Perú%20PE!%20.%20.%20.%20Ven%20con%20nosotros%20y%20se%20parte%20de%20la%20comunidad%20de%20Brasper%20Transferencias!%20;)%20-%20-%20-%20https://rb.gy/vjpce3*%20'
    var url='https://wa.me/?text=*Hola,%20estas%20a%20un%20paso%20de%20comenzar%20una%20nueva%20experiencia%20con%20tus%20Envíos%20Online%20a%20Brasil%20BR%20y%20Perú%20PE%20.%20.%20.%20Ven%20con%20nosotros%20y%20se%20parte%20de%20la%20comunidad%20de%20Brasper%20Transferencias!*%20;)%20https://rb.gy/vjpce3'
    window.location.href = url;
    
}