export function cambio(){
    var valeletipmonenv=eletipmonenv.value;
    calculadora.resultado(valeletipmonenv);
}