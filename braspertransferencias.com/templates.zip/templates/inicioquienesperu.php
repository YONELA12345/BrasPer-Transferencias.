<div id="somosperu" class="bgblanco centro">
    <div>
        <div class="centro">
            <div style="height:35px"></div>
            <div style="text-align: center;color:rgba(44, 56, 189,1);"><h1>&iquest; Quienes Somos &#63;</h1></div>
            <div style="padding: 40px;text-align:center;">
                Brasper Transferencias es una empresa de envíos de remesas online “Fintech de envíos” que nació debido a la necesidad de poder hacer envíos internacionales desde la comodidad de su casa y con el mejor tipo de cambios y el mejor servicio de envíos de Brasil hacia Perú y de Perú a Brasil.<br><br>
                “Confianza, seguridad y rapidez en sus envíos”<br><br>
                Nuestro servicio se basa en la mayor rapidez, así su envío llega a su cuenta de destino en minutos y directo a su cuenta de destino. La seguridad es primordial para nosotros, así nosotros le garantizamos su rápido y correcto envío con la seriedad y honestidad que nos caracteriza.<br><br>
                “Conoce, disfruta y aprovecha de nuestro excelente servicio en Brasper Transferencias”<br>
                Somos una empresa correctamente registrados tanto en Perú como en Brasil:<br>
                RUC: 20608550454, BRASPER 21 S.A.C.<br>
                CNPJ en Brasil: 50.754.016/0001-68, Razão Social: Brasper 21 Corretora De Câmbio Ltda
            </div>
            <div style="height:35px"></div>
        </div>
    </div>
</div>