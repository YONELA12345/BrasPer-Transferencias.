<div style="background:rgba(76,0,102,1);font-size:35px;">
    <div style="height:35px;"></div>
    <div class="container-slider">
        <div class="slider" id="slider">
            <div class="fontbebas txtblanco slider_section" data-age="uno">
                ¡¡Transferencias inmediatas, seguras y directas a la cuenta del destino a una tarifa premium para sus envíos!!
            </div>
            <div class="fontbebas txtblanco slider_section" data-age="uno">
                ¡Con BrasPer Transferencias olvídese de las largas esperas para que tus remesas lleguen a su destino!!
            </div>
            <div class="fontbebas txtblanco slider_section" data-age="uno">
                Si desea enviar dinero de Brasil a Perú o de Perú a Brasil, comuníquese con nosotros.
    ¡Compare, pruebe y disfrute nuestro excelente servicio!
            </div>
        </div>
    </div>
    <div style="height:35px;"></div>
</div>
{% block JS %}
    <script type="text/javascript" src="{{url_for('static',filename='js/iniciotransferencias.js')}}"></script>
{% endblock%}