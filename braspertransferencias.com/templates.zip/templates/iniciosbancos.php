<div id="iniciopasos" class="bgblanco centro">
    <div class="centro">
        <div style='height:20px;'></div>
        <div id='sliderbancos'>
            <div class="cuerpoflex">
                <div class="cuadrospasos sliderbancosimg">
                    <center>
                        <img src="{{url_for('static',filename='img/bcp.jpeg')}}" class="imgpasos">
                    </center>
                </div>
                <div class="cuadrospasos sliderbancosimg">
                    <center>
                        <img src="{{url_for('static',filename='img/interbank.jpeg')}}" class="imgpasos">
                    </center>
                </div>
                <div class="cuadrospasos sliderbancosimg">
                    <center>
                        <img src="{{url_for('static',filename='img/bdb.png')}}" class="imgpasos">
                    </center>
                </div>
                <div class="cuadrospasos sliderbancosimg">
                    <center>
                        <img src="{{url_for('static',filename='img/nubank.png')}}" class="imgpasos">
                    </center>
                </div>
                <div class="cuadrospasos sliderbancosimg">
                    <center>
                        <img src="{{url_for('static',filename='img/c6bank.png')}}" class="imgpasos">
                    </center>
                </div>
                <div class="cuadrospasos sliderbancosimg">
                    <center>
                        <img src="{{url_for('static',filename='img/bancocontinental.png')}}" class="imgpasos">
                    </center>
                </div>
                <div class="cuadrospasos sliderbancosimg">
                    <center>
                        <img src="{{url_for('static',filename='img/yapeplin.png')}}" class="imgpasos">
                    </center>
                </div>
            </div>
        </div>
        <div style='height:20px;'></div>
    </div>
</div>