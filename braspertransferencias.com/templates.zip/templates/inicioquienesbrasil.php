<div id="somosperu" class="bgblanco centro">
    <div class="centro">
        <div style="height:35px"></div>
        <div style="text-align: center;color:rgba(44, 56, 189,1);"><h1>&iquest; Quem somos &#63;</h1></div>
        <div style="padding: 40px;text-align:center;">
        Brasper Transferencias é uma empresa de envio de remessas online “Fintech de envios” que nasceu da necessidade de poder fazer remessas internacionais no conforto da sua casa e com a melhor taxa de câmbio e o melhor serviço de remessa do Brasil para o Peru e do Peru para o Brasil.<br><br>
“Confiança, segurança e rapidez nos seus envios<br><br>
Nosso serviço é baseado na maior rapidez e segurança, para que sua remessa chegue à sua conta de destino em minutos e diretamente na sua conta de destino. A segurança é primordial para nós, por isso garantimos um envio rápido e correto com a seriedade e honestidade que nos caracteriza.<br><br>
“Conheça, curta e aproveite nosso excelente atendimento na Brasper Transferencias”<br><br>
Somos uma empresa devidamente registrada no Brasil e no Peru:<br><br>
CNPJ no Brasil: 50.754.016/0001-68, Razão Social:<br><br> Brasper 21 Corretora De Câmbio Ltda
RUC: 20608550454, BRASPER 21 S.A.C.
        </div>
        <div style="height:35px"></div>
    </div>
</div>