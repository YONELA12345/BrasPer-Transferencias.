{% include 'calculadora.html' %}
{% include 'bannerflaquita.html'%}
{% include 'inicioquienesperu.html' %}
{% include 'iniciotransferencias.html' %}
{% include 'iniciospasos.html' %}
{% include 'iniciorealizapagos.html' %}
{% include 'iniciosbancos.html' %}
{% include 'iniciorealizacotizacion.html' %}