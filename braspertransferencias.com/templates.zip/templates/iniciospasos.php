<div id="iniciopasos" class="bgblanco centro">
    <div class="centro">
        <div style="height:35px"></div>
        <div style="text-align: center;color:rgba(44, 56, 189,1);"><h1>&iquest; C&oacute;mo Funciona &#63;</h1></div>
        <div style="height: 35px;"></div>
        <div style="display:flex;flex-wrap:wrap;">
            <div class="cuadrospasos">
                <center>
                    <img src="{{url_for('static',filename='img/brasper1.png')}}" class="imgpasos">
                </center>
                <div>
                    Cotiza e ingresa el monto que deseas cambiar.
                </div>
            </div>
            <div class="cuadrospasos">
                <center>
                    <img src="{{url_for('static',filename='img/brasper2.png')}}" class="imgpasos">
                </center>
                <div>
                    Regístrate y realiza la transferencia a la cuenta de BrasPer Transferencias y envíanos la constancia de la operación.
                </div>
            </div>
            <div class="cuadrospasos">
                <center>
                    <img src="{{url_for('static',filename='img/brasper3.png')}}" class="imgpasos">
                </center>
                <div>
                    Recibe tu cambio. Te abonaremos el dinero a la cuenta registrada.
                </div>
            </div>
        </div>
        <div style="height:30px;"></div>
    </div>
</div>