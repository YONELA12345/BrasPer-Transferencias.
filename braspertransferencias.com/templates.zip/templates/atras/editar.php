
<div>
    <div>
        <input type="text" placeholder="titulo">
    </div>
    <div>
        <textarea placeholder="descripcion"></textarea>
    </div>
</div>