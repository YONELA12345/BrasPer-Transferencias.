{% extends './atras/home.html' %}
{%block cuerpo%}
    <div>blog</div>
{%endblock%}