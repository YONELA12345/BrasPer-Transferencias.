<div id="iniciopasos" class="bgblanco centro">
    <div class="centro">
        <div style="height:35px"></div>
        <div style="text-align: center;color:rgba(44, 56, 189,1);"><h1>&iquest; Como Funciona &#63;</h1></div>
        <div style="height:35px"></div>
        <div style="display:flex;flex-wrap:wrap;">
            <div class="cuadrospasos">
                <center>
                    <img src="{{url_for('static',filename='img/brasper1.png')}}" class="imgpasos">
                </center>
                <div>
                    aça uma cotação e digite o valor que deseja enviar.
                </div>
            </div>
            <div class="cuadrospasos">
                <center>
                    <img src="{{url_for('static',filename='img/brasper2.png')}}" class="imgpasos">
                </center>
                <div>
                    Cadastre-se e faça a transferência para a conta da BrasPer Transferências e nos envie o comprovante da operação.
                </div>
            </div>
            <div class="cuadrospasos">
                <center>
                    <img src="{{url_for('static',filename='img/brasper3.png')}}" class="imgpasos">
                </center>
                <div>
                    Conheça quanto irá chegar na conta de destino. Vamos creditar o dinheiro na conta de destino.
                </div>
            </div>
        </div>
        <div style="height:30px;"></div>
    </div>
</div>