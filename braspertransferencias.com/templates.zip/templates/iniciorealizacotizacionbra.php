<?php

?>
<div class="bgazulcorporativo centro">
    <div class="centro">
        <div class="altura35"></div>
        <div class="cuerpoflex">
            <div class="centro" style="width:40%;">
                <center>
                    <img src="{{url_for('static',filename='img/braspercel2.png')}}" class="imgmapa">
                </center>
            </div>
            <div class="centro txtcentro txt30 txtblanco fontbebas" style="padding:10px;width:60%">
                É só inserir o valor em nossa calculadora e realize a conversão. Conheça a taxa de câmbio e realize a operação.
            </div>
        </div>
        <div class="altura35"></div>
    </div>
</div>