<div class="bgazulcorporativo centro">
    <div class="centro">
        <div style="height:30px;"></div>
        <div class="flex">
            <div class="centro txtcentro fontbebas txt30 txtblanco" style="padding:10px;width:60%">
                Se você deseja enviar dinheiro do Brasil para o Peru ou do Peru para o Brasil, entre em contato conosco. Experimente e compare o nosso serviço!
            </div>
            <div class="centro" style="width:40%;">
                <center>
                    <img src="{{url_for('static',filename='img/braspermapa2.png')}}" class="imgmapa">
                </center>
            </div>
        </div>
        <div style="height:30px;"></div>
    </div>
</div>