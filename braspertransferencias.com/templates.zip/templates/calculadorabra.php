<input type="text" id='soladol' value="{{cambio[1]}}" hidden>
<input type="text" id='solareal' value="{{cambio[2]}}" hidden>
<input type="text" id='usdasol' value="{{cambio[3]}}" hidden>
<input type="text" id='usdareal' value="{{cambio[4]}}" hidden>
<input type="text" id='realapen' value="{{cambio[5]}}" hidden>
<input type="text" id='realausd' value="{{cambio[6]}}" hidden>
<!--penabrl//-->
{% for cpenabrl in copenabrl %}
<input type="text" id="co100a199penabrl" value="{{cpenabrl[1]}}" hidden>
<input type="text" id="co200a299penabrl" value="{{cpenabrl[2]}}" hidden>
<input type="text" id="co300a499penabrl" value="{{cpenabrl[3]}}" hidden>
<input type="text" id="co500a999penabrl" value="{{cpenabrl[4]}}" hidden>
<input type="text" id="co1000a2999penabrl" value="{{cpenabrl[5]}}" hidden>
<input type="text" id="co3000a5000penabrl" value="{{cpenabrl[6]}}" hidden>
{% endfor %}
{% for inpenabrl in invpenabrl %}
<input type="text" id="in100a199penabrl" value="{{inpenabrl[1]}}"hidden>
<input type="text" id="in200a299penabrl" value="{{inpenabrl[2]}}" hidden>
<input type="text" id="in300a499penabrl" value="{{inpenabrl[3]}}" hidden>
<input type="text" id="in500a999penabrl" value="{{inpenabrl[4]}}" hidden>
<input type="text" id="in1000a2999penabrl" value="{{inpenabrl[5]}}" hidden>
<input type="text" id="in3000a5000penabrl" value="{{inpenabrl[6]}}" hidden>
{% endfor %}
<!--brlapen//-->
{% for cbrlapen in cobrlapen %}
<input type="text" id="co100a199brlapen" value="{{cbrlapen[1]}}" hidden>
<input type="text" id="co200a299brlapen" value="{{cbrlapen[2]}}" hidden>
<input type="text" id="co300a499brlapen" value="{{cbrlapen[3]}}" hidden>
<input type="text" id="co500a999brlapen" value="{{cbrlapen[4]}}" hidden>
<input type="text" id="co1000a2999brlapen" value="{{cbrlapen[5]}}" hidden>
<input type="text" id="co3000a5000brlapen" value="{{cbrlapen[6]}}" hidden>
{% endfor %}
{% for inbrlapen in invbrlapen %}
<input type="text" id="in100a199brlapen" value="{{inbrlapen[1]}}" hidden>
<input type="text" id="in200a299brlapen" value="{{inbrlapen[2]}}" hidden>
<input type="text" id="in300a499brlapen" value="{{inbrlapen[3]}}" hidden>
<input type="text" id="in500a999brlapen" value="{{inbrlapen[4]}}" hidden>
<input type="text" id="in1000a2999brlapen" value="{{inbrlapen[5]}}" hidden>
<input type="text" id="in3000a5000brlapen" value="{{inbrlapen[6]}}" hidden>
{% endfor %}
<!--brlausd//-->
{% for cbrlausd in cobrlausd %}
<input type="text" id="co100a199brlausd" value="{{cbrlausd[1]}}" hidden>
<input type="text" id="co200a299brlausd" value="{{cbrlausd[2]}}" hidden>
<input type="text" id="co300a499brlausd" value="{{cbrlausd[3]}}" hidden>
<input type="text" id="co500a999brlausd" value="{{cbrlausd[4]}}" hidden>
<input type="text" id="co1000a2999brlausd" value="{{cbrlausd[5]}}" hidden>
<input type="text" id="co3000a5000brlausd" value="{{cbrlausd[6]}}" hidden>
{% endfor %}
{% for inbrlausd in invbrlausd %}
<input type="text" id="in100a199brlausd" value="{{inbrlausd[1]}}" hidden>
<input type="text" id="in200a299brlausd" value="{{inbrlausd[2]}}" hidden>
<input type="text" id="in300a499brlausd" value="{{inbrlausd[3]}}" hidden>
<input type="text" id="in500a999brlausd" value="{{inbrlausd[4]}}" hidden>
<input type="text" id="in1000a2999brlausd" value="{{inbrlausd[5]}}" hidden>
<input type="text" id="in3000a5000brlausd" value="{{inbrlausd[6]}}" hidden>
{% endfor %}
<!--usdabrl//-->
{% for cusdabrl in cousdabrl %}
<input type="text" id="co100a199usdabrl" value="{{cusdabrl[1]}}" hidden>
<input type="text" id="co200a299usdabrl" value="{{cusdabrl[2]}}" hidden>
<input type="text" id="co300a499usdabrl" value="{{cusdabrl[3]}}" hidden>
<input type="text" id="co500a999usdabrl" value="{{cusdabrl[4]}}" hidden>
<input type="text" id="co1000a2999usdabrl" value="{{cusdabrl[5]}}" hidden>
<input type="text" id="co3000a5000usdabrl" value="{{cusdabrl[6]}}" hidden>
{% endfor %}
{% for inusdabrl in invusdabrl %}
<input type="text" id="in100a199usdabrl" value="{{inusdabrl[1]}}" hidden>
<input type="text" id="in200a299usdabrl" value="{{inusdabrl[2]}}" hidden>
<input type="text" id="in300a499usdabrl" value="{{inusdabrl[3]}}" hidden>
<input type="text" id="in500a999usdabrl" value="{{inusdabrl[4]}}" hidden>
<input type="text" id="in1000a2999usdabrl" value="{{inusdabrl[5]}}" hidden>
<input type="text" id="in3000a5000usdabrl" value="{{inusdabrl[6]}}" hidden>
{% endfor %}
<!--penausd//-->
{% for cpenausd in copenausd %}
<input type="text" id="co100a199penausd" value="{{cpenausd[1]}}" hidden>
<input type="text" id="co200a299penausd" value="{{cpenausd[2]}}" hidden>
<input type="text" id="co300a499penausd" value="{{cpenausd[3]}}" hidden>
<input type="text" id="co500a999penausd" value="{{cpenausd[4]}}" hidden>
<input type="text" id="co1000a2999penausd" value="{{cpenausd[5]}}" hidden>
<input type="text" id="co3000a5000penausd" value="{{cpenausd[6]}}" hidden>
{% endfor %}
{% for inpenausd in invpenausd %}
<input type="text" id="in100a199penausd" value="{{inpenausd[1]}}" hidden>
<input type="text" id="in200a299penausd" value="{{inpenausd[2]}}" hidden>
<input type="text" id="in300a499penausd" value="{{inpenausd[3]}}" hidden>
<input type="text" id="in500a999penausd" value="{{inpenausd[4]}}" hidden>
<input type="text" id="in1000a2999penausd" value="{{inpenausd[5]}}" hidden>
<input type="text" id="in3000a5000penausd" value="{{inpenausd[6]}}" hidden>
{% endfor %}
<!--usdapen//-->
{% for cusdapen in cousdapen %}
<input type="text" id="co100a199usdapen" value="{{cusdapen[1]}}" hidden>
<input type="text" id="co200a299usdapen" value="{{cusdapen[2]}}" hidden>
<input type="text" id="co300a499usdapen" value="{{cusdapen[3]}}" hidden>
<input type="text" id="co500a999usdapen" value="{{cusdapen[4]}}" hidden>
<input type="text" id="co1000a2999usdapen" value="{{cusdapen[5]}}" hidden>
<input type="text" id="co3000a5000usdapen" value="{{cusdapen[6]}}" hidden>
{% endfor %}
{% for inusdapen in invusdapen %}
<input type="text" id="in100a199usdapen" value="{{inusdapen[1]}}" hidden>
<input type="text" id="in200a299usdapen" value="{{inusdapen[2]}}" hidden>
<input type="text" id="in300a499usdapen" value="{{inusdapen[3]}}" hidden>
<input type="text" id="in500a999usdapen" value="{{inusdapen[4]}}" hidden>
<input type="text" id="in1000a2999usdapen" value="{{inusdapen[5]}}" hidden>
<input type="text" id="in3000a5000usdapen" value="{{inusdapen[6]}}" hidden>
{% endfor %}
<!--//-->
<style>
    #popup{
        display:none;
    
    }
    .imgpromo{
        width: 100%;
        margin:auto;
    }
    #botupclose{
        background:rgba(255,255,255,1);text-align: right;font-size: 15px;
        color:rgba(0,0,0,1);padding: 12px;cursor: pointer;font-weight: bold;
    }
    #botupclose:hover{
        color: rgba(123,123,123,1);
    }
    .cont{
        width:50%;
    }
    @media (orientation=portrait){
        #botupclose{
            font-size: 15px;
        }
        .cont{
            width: 90%;
        }
    }
</style>
<div id='popup'>
   <div style='display:flex;justify-content:center;align-items: center;width:100%;height:100%;'>
        <div class='cont'>
            <div id="botupclose">
                CERRAR
            </div>
            <div style='margin:auto;'>
                <enter>
                    <img src="{{url_for('static',filename='img/popup3.jpg')}}" class="imgpromo">
                </enter>
            </div>
       </div>
   </div>
</div>
<div class="alto25"></div>
<center>
<div style="padding:12px;margin:auto;">
    <div style="padding:10px;width:350px;height:550px;border-radius:5px;" class="fondoblan" id='ventanacalculadora'>
        <div class="fontbebas txtcentro txt30"> 
            Insira o valor a ser enviado
        </div>
        <div style="margin:auto;">
            <div class="centro alto15">
                <div class="padding10 txtroboto txt20" style="color:rgba(0,0,255,1);">
                    Envías
                </div>
                <div class="circuturquesa flex alrededor">
                    <div style="margin-top:10px;">
                        <span>
                            <input type='text' placeholder="0.00" id="inputmontoenviar" style="font-size:25px;"/>
                        </span>
                    </div>
                    <div id="enviomoneda">
                        <ul class="nav">
                            <li class="fontbebas">
                                <div onclick="calculadora.resultado('penbrl')" style="display:flex;justify-content: flex-end;">
                                    <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                    <div style="padding:10px;">&nbsp;PEN Perú</div>
                                    <div style="width: 0;height: 0;border-right: 10px solid transparent;border-top: 10px solid transparent;border-left: 10px solid transparent;border-bottom: 10px solid #f0ad4e;transform: rotate(180deg); "></div>
                                </div>
                                <ul>
                                    <li>
                                        <div onclick="calculadora.resultado('usdbrl')" style="display:flex;justify-content: flex-end;">
                                            <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                            <div style="padding:10px;">&nbsp;USD PEN</div>
                                        </div>
                                    </li>
                                    <li>
                                        <div onclick="calculadora.resultado('brlpen')" style="display:flex;justify-content: flex-end;">
                                            <img src="{{url_for('static',filename='img/bra.png')}}" style="width:50px;height:35px;">
                                            <div style="padding:10px;">&nbsp;BRL Brasil</div>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
                <div>
                    <input type='text' id="eletipmonenv" value='penbrl' hidden/>
                    {% for comis in comis %}
                        <input type="text" id="comision100a199" value="{{comis[1]}}" hidden>
                        <input type="text" id="comision200a299" value="{{comis[2]}}" hidden>
                        <input type="text" id="comision300a499" value="{{comis[3]}}" hidden>
                        <input type="text" id="comision500a999" value="{{comis[4]}}" hidden>
                        <input type="text" id="comision1000a2999" value="{{comis[5]}}" hidden>
                        <input type="text" id="comision3000a5000" value="{{comis[6]}}" hidden>
                    {% endfor %}
                    {% for calin in calcin %}
                        <input type="text" id="inversacomision100a199" value="{{calin[1]}}" hidden>
                        <input type="text" id="inversacomision200a299" value="{{calin[2]}}" hidden>
                        <input type="text" id="inversacomision300a499" value="{{calin[3]}}" hidden>
                        <input type="text" id="inversacomision500a999" value="{{calin[4]}}" hidden>
                        <input type="text" id="inversacomision1000a2999" value="{{calin[5]}}" hidden>
                        <input type="text" id="inversacomision3000a5000" value="{{calin[6]}}" hidden>
                    {% endfor %}
                    <input type="text" id="comisiontresporciento" value="0.03" hidden>
                    <input type="text" id="tcambio" hidden/>
                    <input type="text" id="tcomisi" hidden/>
                    <input type="text" id="timpues" hidden/>
                    <input type="text" id="ttotale" hidden/>
                    <input type="text" id="tenviar" hidden/>
                    <input type="text" id="trecibe" hidden/>
                    <input type="text" id="tmoneda" hidden/>
                    <input type="text" id="posiciona" hidden/>
                </div>
                <div id="errorenvio" style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;color:rgba(255,0,0,1);font-size:17px;text-align:center;"></div>
                <div id="operaciones">
                    <div class="centro txt25">
                        <div class="flex flexend">
                            <table>
                                <tr><td>
                                    <div style="display:flex;">
                                        <span style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;font-size:17px;">
                                            Taxa de envio:
                                        </span>
                                        <div style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;color:rgba(255,0,0,1);font-size:15px;" id='numcomision'>
                                        </div>
                                    </div>
                                </td><td>
                                    <div id="tipodecomision" style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;color:rgba(255,0,0,1);font-size:17px;">0.00</div>
                                </td></tr>
                                <tr><td>
                                    <span style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;font-size:17px;">Impostos:&nbsp;</span>
                                </td><td>
                                    <div id="tipodeimpuestos" style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;color:rgba(255,0,0,1);font-size:17px;">0.00</div>
                                </td></tr>
                                <tr><td>
                                    <span style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;font-size:17px;">Total a ser convertido::&nbsp;</span>
                                </td><td>
                                    <div id="tipototalenviar" style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;color:rgba(255,0,0,1);font-size:17px;">0.00</div>
                                </td></tr>
                                <tr><td>
                                    <span style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;font-size:17px;">Taxa de câmbio:&nbsp;</span>
                                </td><td>
                                    <div id="tipodecambio" style="font-weight:bold;line-height: 20px;font-family: 'Roboto', sans-serif;color:rgba(255,0,0,1);font-size:17px;">0.000</div>
                                </td></tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="centro">
                    <div class="padding10 txtroboto txt20" style="color:rgba(0,0,255,1);">
                        Recebe
                    </div>
                    <div class="circuturquesa flex alrededor">
                        <div style="padding:10px;">
                            <span style="font-size:15px;font-weight:bold;line-height: 30px;font-family: 'Roboto', sans-serif;font-size:25px;">
                                <input type='text' placeholder="0.00" id="tipototalrecibe" style="font-size:25px;border:0px solid;"/>
                            </span>
                        </div>
                        <div id="recibemoneda">
                            <div style="display:flex;justify-content: flex-end;">
                                <img src="{{url_for('static',filename='img/bra.png')}}" style="width:50px;height:35px;">
                                <div style="padding:10px;">&nbsp;BRL Brasil</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="height:10px;"></div>
                <div style="font-family: 'Roboto', sans-serif;" id="btnsiguiente">
                    <input type="checkbox" onclick="calculadora.mostrar()"/>&nbsp;<a href="vistas/modulos/terminosycondiciones.pdf" target="_blank">Acepto Términos y Condiciones</a>
                </div>
                <div style="height:10px;"></div>
                <div>
                    <div class="bgazulcorporativo txtroboto txtblanco centro" style="width:250px;text-align:center;padding:10px;border-radius:5px;cursor:pointer;" id="btnsiguientese" onclick="calculadora.whatsapp()">
                        ENVIAR DINERO
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div style="height:50px;"></div>
</center>
<script type="text/javascript">
var popup=document.getElementById('popup');
popup.style.position='absolute';
popup.style.width='100vw';
popup.style.height='100vh';
popup.style.background='rgba(0,0,0,0.7)';
popup.style.zIndex='10';
var botupclose=document.getElementById('botupclose');
botupclose.addEventListener('click',function(){popup.style.display='none';})
var btnsiguientese=document.getElementById('btnsiguientese');
btnsiguientese.style.display='none';
var posiciona=document.getElementById('posiciona');
var ventanacalculadora=document.getElementById('ventanacalculadora');
ventanacalculadora.style.display='block';
var errorenvio=document.getElementById('errorenvio');
errorenvio.style.display='none';
var eletipmonenv=document.getElementById('eletipmonenv');

var comision100a199=document.getElementById("comision100a199");
var comision200a299=document.getElementById("comision200a299");
var comision300a499=document.getElementById("comision300a499");
var comision500a999=document.getElementById("comision500a999");
var comision1000a2999=document.getElementById("comision1000a2999");
var comision3000a5000=document.getElementById("comision3000a5000");
var inversacomision100a199=document.getElementById("inversacomision100a199");
var inversacomision200a299=document.getElementById("inversacomision200a299");
var inversacomision300a499=document.getElementById("inversacomision300a499");
var inversacomision500a999=document.getElementById("inversacomision500a999");
var inversacomision1000a2999=document.getElementById("inversacomision1000a2999");
var inversacomision3000a5000=document.getElementById("inversacomision3000a5000");

var co1000a5000usdbrl=0.035;//3.5%
var co1000a5000brlusd=0.035;//3.5%
var in1000a5000usdbrl=0.9587;//3.5%
var in1000a5000brlusd=0.9587;//3.5

/**penabrl**/
var co100a199penabrl=document.getElementById('co100a199penabrl');
var co200a299penabrl=document.getElementById('co200a299penabrl');
var co300a499penabrl=document.getElementById('co300a499penabrl');
var co500a999penabrl=document.getElementById('co500a999penabrl');
var co1000a2999penabrl=document.getElementById('co1000a2999penabrl');
var co3000a5000penabrl=document.getElementById('co3000a5000penabrl');
var in100a199penabrl=document.getElementById('in100a199penabrl');
var in200a299penabrl=document.getElementById('in200a299penabrl');
var in300a499penabrl=document.getElementById('in300a499penabrl');
var in500a999penabrl=document.getElementById('in500a999penabrl');
var in1000a2999penabrl=document.getElementById('in1000a2999penabrl');
var in3000a5000penabrl=document.getElementById('in3000a5000penabrl');

/**brlapen**/
var co100a199brlapen=document.getElementById('co100a199brlapen');
var co200a299brlapen=document.getElementById('co200a299brlapen');
var co300a499brlapen=document.getElementById('co300a499brlapen');
var co500a999brlapen=document.getElementById('co500a999brlapen');
var co1000a2999brlapen=document.getElementById('co1000a2999brlapen');
var co3000a5000brlapen=document.getElementById('co3000a5000brlapen');
var in100a199brlapen=document.getElementById('in100a199brlapen');
var in200a299brlapen=document.getElementById('in200a299brlapen');
var in300a499brlapen=document.getElementById('in300a499brlapen');
var in500a999brlapen=document.getElementById('in500a999brlapen');
var in1000a2999brlapen=document.getElementById('in1000a2999brlapen');
var in3000a5000brlapen=document.getElementById('in3000a5000brlapen');
/**brlausd**/
var co100a199brlausd=document.getElementById('co100a199brlausd');
var co200a299brlausd=document.getElementById('co200a299brlausd');
var co300a499brlausd=document.getElementById('co300a499brlausd');
var co500a999brlausd=document.getElementById('co500a999brlausd');
var co1000a2999brlausd=document.getElementById('co1000a2999brlausd');
var co3000a5000brlausd=document.getElementById('co3000a5000brlausd');
var in100a199brlausd=document.getElementById('in100a199brlausd');
var in200a299brlausd=document.getElementById('in200a299brlausd');
var in300a499brlausd=document.getElementById('in300a499brlausd');
var in500a999brlausd=document.getElementById('in500a999brlausd');
var in1000a2999brlausd=document.getElementById('in1000a2999brlausd');
var in3000a5000brlausd=document.getElementById('in3000a5000brlausd');
/**usdabrl**/
var co100a199usdabrl=document.getElementById('co100a199usdabrl');
var co200a299usdabrl=document.getElementById('co200a299usdabrl');
var co300a499usdabrl=document.getElementById('co300a499usdabrl');
var co500a999usdabrl=document.getElementById('co500a999usdabrl');
var co1000a2999usdabrl=document.getElementById('co1000a2999usdabrl');
var co3000a5000usdabrl=document.getElementById('co3000a5000usdabrl');
var in100a199usdabrl=document.getElementById('in100a199usdabrl');
var in200a299usdabrl=document.getElementById('in200a299usdabrl');
var in300a499usdabrl=document.getElementById('in300a499usdabrl');
var in500a999usdabrl=document.getElementById('in500a999usdabrl');
var in1000a2999usdabrl=document.getElementById('in1000a2999usdabrl');
var in3000a5000usdabrl=document.getElementById('in3000a5000usdabrl');
/**penausd**/
var co100a199penausd=document.getElementById('co100a199penausd');
var co200a299penausd=document.getElementById('co200a299penausd');
var co300a499penausd=document.getElementById('co300a499penausd');
var co500a999penausd=document.getElementById('co500a999penausd');
var co1000a2999penausd=document.getElementById('co1000a2999penausd');
var co3000a5000penausd=document.getElementById('co3000a5000penausd');
var in100a199penausd=document.getElementById('in100a199penausd');
var in200a299penausd=document.getElementById('in200a299penausd');
var in300a499penausd=document.getElementById('in300a499penausd');
var in500a999penausd=document.getElementById('in500a999penausd');
var in1000a2999penausd=document.getElementById('in1000a2999penausd');
var in3000a5000penausd=document.getElementById('in3000a5000penausd');
/**usdapen**/
var co100a199usdapen=document.getElementById('co100a199usdapen');
var co200a299usdapen=document.getElementById('co200a299usdapen');
var co300a499usdapen=document.getElementById('co300a499usdapen');
var co500a999usdapen=document.getElementById('co500a999usdapen');
var co1000a2999usdapen=document.getElementById('co1000a2999usdapen');
var co3000a5000usdapen=document.getElementById('co3000a5000usdapen');
var in100a199usdapen=document.getElementById('in100a199usdapen');
var in200a299usdapen=document.getElementById('in200a299usdapen');
var in300a499usdapen=document.getElementById('in300a499usdapen');
var in500a999usdapen=document.getElementById('in500a999usdapen');
var in1000a2999usdapen=document.getElementById('in1000a2999usdapen');
var co3000a5000usdapen=document.getElementById('co3000a5000usdapen');

var inversa;
var comision;
var impuesto=0.18;
var recibemoneda=document.getElementById('recibemoneda');
var enviomoneda=document.getElementById('enviomoneda');
var valcomision;
var valcomenviar;
var valimpuestos;
var valtotalcomimp;
var valtotalenviar;
var tipodeimpuestos=document.getElementById('tipodeimpuestos');
var tipodecambio=document.getElementById('tipodecambio');
var tipodecomision=document.getElementById('tipodecomision');
var tipototalenviar=document.getElementById('tipototalenviar');
var valtotalrecibe=document.getElementById('valtotalrecibe');
var tipototalrecibe=document.getElementById('tipototalrecibe');
var numcomision=document.getElementById('numcomision');
var btnsiguiente=document.getElementById('btnsiguiente');
var tmoneda=document.getElementById('tmoneda');
btnsiguiente.style.display='none';
inputmontoenviar.addEventListener('change',function(){
    calculadora.cambio();
});
tipototalrecibe.addEventListener('change',function(){
    calculadora.abajaso();
});
var tcambio=document.getElementById('tcambio');
var tcomisi=document.getElementById('tcomisi');
var timpues=document.getElementById('timpues');
var ttotale=document.getElementById('ttotale');
var tenviar=document.getElementById('tenviar');
var trecibe=document.getElementById('trecibe');
var cantidadorigen=document.getElementById('cantidadorigen');
var cantidadcambio=document.getElementById('cantidadcambio');
var cantidadcomision=document.getElementById('cantidadcomision');
var cantidadimpuestos=document.getElementById('cantidadimpuestos');
var cantidadenviar=document.getElementById('cantidadenviar');
var cantidadrecibe=document.getElementById('cantidadrecibe');
var calculadora={
    cambio:function(){
        var valeletipmonenv=eletipmonenv.value;
        calculadora.resultado(valeletipmonenv);
    },
    resultado:function(e){
        posiciona.value='arriva';
        var valeletipmonenv=eletipmonenv.value;
        var soladol=document.getElementById('soladol').value;
        var solareal=document.getElementById('solareal').value;
        var usdasol=document.getElementById('usdasol').value;
        var usdareal=document.getElementById('usdareal').value;
        var realapen=document.getElementById('realapen').value;
        var realausd=document.getElementById('realausd').value;
        var valsoldol=parseFloat(soladol).toFixed(3);
        var valsolrea=parseFloat(solareal).toFixed(3);
        var valusdasol=parseFloat(usdasol).toFixed(3);
        var valusdareal=parseFloat(usdareal).toFixed(3);
        var valrealapen=parseFloat(realapen).toFixed(3);
        var valrealausd=parseFloat(realausd).toFixed(3);
        switch(e){
            case('penbrl'):
                eletipmonenv.value=e;
                enviomoneda.innerHTML=`
                    <ul class="nav">
                        <li class="fontbebas">
                            <div onclick="" style="display:flex;justify-content: flex-end;">
                                <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                <div style="padding:10px;">&nbsp;PEN Perú</div>
                                <div style="width: 0;height: 0;border-right: 10px solid transparent;border-top: 10px solid transparent;border-left: 10px solid transparent;border-bottom: 10px solid #f0ad4e;transform: rotate(180deg); "></div>
                            </div>
                            <ul>
                                <li>
                                    <div onclick="calculadora.resultado('usdbrl')" style="display:flex;justify-content: flex-end;">
                                        <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                        <div style="padding:10px;">&nbsp;USD PEN</div>
                                    </div>
                                </li>
                                <li>
                                    <div onclick="calculadora.resultado('brlpen')" style="display:flex;justify-content: flex-end;">
                                        <img src="{{url_for('static',filename='img/bra.png')}}" style="width:50px;height:35px;">
                                        <div style="padding:10px;">&nbsp;BRL Brasil</div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                `;
                recibemoneda.innerHTML=`
                    <div style="display:flex;justify-content: flex-end;">
                        <img src="{{url_for('static',filename='img/bra.png')}}" style="width:50px;height:35px;">
                        <div style="padding:10px;">&nbsp;BRL Brasil</div>
                    </div>
                `;
                var valmonto=inputmontoenviar.value;
                if(valmonto<100){
                    errorenvio.style.display='block';
                    errorenvio.innerHTML='Ingrese Monto mayor a 100';
                    tipodeimpuestos.innerHTML="0.00";
                    tipodecambio.innerHTML="0.00";
                    tipodecomision.innerHTML="0.00";
                    tipototalenviar.innerHTML="0.00";
                    tipototalrecibe.value="0.00";
                    numcomision.innerHTML="0.00";
                    tcambio.value=0;
                    tcomisi.value=0;
                    timpues.value=0;
                    ttotale.value=0;
                    tenviar.value=0;
                    trecibe.value=0;
                    tmoneda.value='Sol a Real';
                    btnsiguiente.style.display='none';
                }else{
                    if(valmonto<200){
                        comision=co100a199penabrl.value;
                        errorenvio.style.display='none';
                        valcomision=(parseFloat(comision)*100).toFixed(2);//3 porciento
                        valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);//monto por 3 porciento
                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);//18% por resultado del 3% del monto
                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);//3% mas 18% del monto a enviar
                        valtotalenviar=(parseFloat(valmonto)-parseFloat(valtotalcomimp)).toFixed(2);//monto menos suma del 3%y18%
                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";//resultado 3%
                        tipodecambio.innerHTML=valsolrea;//tipo de cambio
                        tipodecomision.innerHTML=+valcomenviar+" PEN";//3% del monto
                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";//monto menos suma 3%y!8%
                        valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valsolrea)).toFixed(2);//monto menos 3%18% po tipo de cambio
                        tipototalrecibe.value=valtotalrecibe;
                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                        tcambio.value=valsolrea;
                        tcomisi.value=valcomenviar;
                        timpues.value=valimpuestos;
                        ttotale.value=valtotalenviar;
                        tenviar.value=valmonto;
                        trecibe.value=valtotalrecibe;
                        tmoneda.value='Sol a Real';
                        btnsiguiente.style.display='block'; 
                    }else{
                        if(valmonto<300){
                            comision=co200a299penabrl.value;
                            errorenvio.style.display='none';
                            valcomision=(parseFloat(comision)*100).toFixed(2);//3 porciento
                            valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);//monto por 3 porciento
                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);//18% por resultado del 3% del monto
                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);//3% mas 18% del monto a enviar
                            valtotalenviar=(parseFloat(valmonto)-parseFloat(valtotalcomimp)).toFixed(2);//monto menos suma del 3%y18%
                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";//resultado 3%
                            tipodecambio.innerHTML=valsolrea;//tipo de cambio
                            tipodecomision.innerHTML=+valcomenviar+" PEN";//3% del monto
                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";//monto menos suma 3%y!8%
                            valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valsolrea)).toFixed(2);//monto menos 3%18% po tipo de cambio
                            tipototalrecibe.value=valtotalrecibe;
                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                            tcambio.value=valsolrea;
                            tcomisi.value=valcomenviar;
                            timpues.value=valimpuestos;
                            ttotale.value=valtotalenviar;
                            tenviar.value=valmonto;
                            trecibe.value=valtotalrecibe;
                            tmoneda.value='Sol a Real';
                            btnsiguiente.style.display='block';
                        }else{
                            if(valmonto<500){
                                comision=co300a499penabrl.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);//3 porciento
                                valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);//monto por 3 porciento
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);//18% por resultado del 3% del monto
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);//3% mas 18% del monto a enviar
                                valtotalenviar=(parseFloat(valmonto)-parseFloat(valtotalcomimp)).toFixed(2);//monto menos suma del 3%y18%
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";//resultado 3%
                                tipodecambio.innerHTML=valsolrea;//tipo de cambio
                                tipodecomision.innerHTML=+valcomenviar+" PEN";//3% del monto
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";//monto menos suma 3%y!8%
                                valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valsolrea)).toFixed(2);//monto menos 3%18% po tipo de cambio
                                tipototalrecibe.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valsolrea;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=valmonto;
                                trecibe.value=valtotalrecibe;
                                tmoneda.value='Sol a Real';
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<1000){
                                    comision=co500a999penabrl.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);//3 porciento
                                    valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);//monto por 3 porciento
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);//18% por resultado del 3% del monto
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);//3% mas 18% del monto a enviar
                                    valtotalenviar=(parseFloat(valmonto)-parseFloat(valtotalcomimp)).toFixed(2);//monto menos suma del 3%y18%
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";//resultado 3%
                                    tipodecambio.innerHTML=valsolrea;//tipo de cambio
                                    tipodecomision.innerHTML=+valcomenviar+" PEN";//3% del monto
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";//monto menos suma 3%y!8%
                                    valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valsolrea)).toFixed(2);//monto menos 3%18% po tipo de cambio
                                    tipototalrecibe.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valsolrea;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=valmonto;
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Sol a Real';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<3000){
                                        comision=co1000a2999penabrl.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);//3 porciento
                                        valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);//monto por 3 porciento
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);//18% por resultado del 3% del monto
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);//3% mas 18% del monto a enviar
                                        valtotalenviar=(parseFloat(valmonto)-parseFloat(valtotalcomimp)).toFixed(2);//monto menos suma del 3%y18%
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";//resultado 3%
                                        tipodecambio.innerHTML=valsolrea;//tipo de cambio
                                        tipodecomision.innerHTML=+valcomenviar+" PEN";//3% del monto
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";//monto menos suma 3%y!8%
                                        valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valsolrea)).toFixed(2);//monto menos 3%18% po tipo de cambio
                                        tipototalrecibe.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valsolrea;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=valmonto;
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Sol a Real';
                                        btnsiguiente.style.display='block'; 
                                    }else{
                                         if(valmonto<=5000){
                                            comision=co3000a5000penabrl.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);//3 porciento
                                            valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);//monto por 3 porciento
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);//18% por resultado del 3% del monto
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);//3% mas 18% del monto a enviar
                                            valtotalenviar=(parseFloat(valmonto)-parseFloat(valtotalcomimp)).toFixed(2);//monto menos suma del 3%y18%
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";//resultado 3%
                                            tipodecambio.innerHTML=valsolrea;//tipo de cambio
                                            tipodecomision.innerHTML=+valcomenviar+" PEN";//3% del monto
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";//monto menos suma 3%y!8%
                                            valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valsolrea)).toFixed(2);//monto menos 3%18% po tipo de cambio
                                            tipototalrecibe.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valsolrea;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=valmonto;
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Sol a Real';
                                            btnsiguiente.style.display='block'; 
                                        }else{
                                            errorenvio.style.display='block';
                                            errorenvio.innerHTML='Ingrese Monto menor a 5000';
                                            tipodeimpuestos.innerHTML="0.00";
                                            tipodecambio.innerHTML="0.00";
                                            tipodecomision.innerHTML="0.00";
                                            tipototalenviar.innerHTML="0.00";
                                            tipototalrecibe.value="0.00";
                                            numcomision.innerHTML="0.00";
                                            tcambio.value=0;
                                            tcomisi.value=0;
                                            timpues.value=0;
                                            ttotale.value=0;
                                            tenviar.value=0;
                                            trecibe.value=0;
                                            tmoneda.value='Sol a Real';
                                            btnsiguiente.style.display='none';
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case('usdbrl'):
                eletipmonenv.value=e;
                enviomoneda.innerHTML=`
                    <ul class="nav">
                        <li class="fontbebas">
                            <div onclick="" style="display:flex;justify-content: flex-end;">
                                <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                <div style="padding:10px;">&nbsp;USD PEN</div>
                                <div style="width: 0;height: 0;border-right: 10px solid transparent;border-top: 10px solid transparent;border-left: 10px solid transparent;border-bottom: 10px solid #f0ad4e;transform: rotate(180deg); "></div>
                             </div>
                            <ul>
                                <li>
                                    <div onclick="calculadora.resultado('penbrl')" style="display:flex;justify-content: flex-end;">
                                    <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                    <div style="padding:10px;">&nbsp;PEN Perú</div>
                                </div>
                                </li>
                                <li>
                                    <div onclick="calculadora.resultado('brlpen')" style="display:flex;justify-content: flex-end;">
                                        <img src="{{url_for('static',filename='img/bra.png')}}" style="width:50px;height:35px;">
                                        <div style="padding:10px;">&nbsp;BRL Brasil</div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                `;
                recibemoneda.innerHTML=`
                    <div style="display:flex;justify-content: flex-end;">
                        <img src="{{url_for('static',filename='img/bra.png')}}" style="width:50px;height:35px;">
                        <div style="padding:10px;">&nbsp;BRL Brasil</div>
                    </div>
                `;
                var valmonto=inputmontoenviar.value;
                if(valmonto<100){
                    errorenvio.style.display='block';
                    errorenvio.innerHTML='Ingrese Monto mayor a 100';
                    tipodeimpuestos.innerHTML="0.00";
                    tipodecambio.innerHTML="0.00";
                    tipodecomision.innerHTML="0.00";
                    tipototalenviar.innerHTML="0.00";
                    tipototalrecibe.value="0.00";
                    numcomision.innerHTML="0.00";
                    tcambio.value=0;
                    tcomisi.value=0;
                    timpues.value=0;
                    ttotale.value=0;
                    tenviar.value=0;
                    trecibe.value=0;
                    tmoneda.value='Dolar a Real';
                    btnsiguiente.style.display='none';
                }else{
                    if(valmonto<200){
                        comision=co100a199usdabrl.value;
                        errorenvio.style.display='none';
                        valcomision=(parseFloat(comision)*100).toFixed(2);
                        valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                        valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;USD";
                        tipodecambio.innerHTML=valusdareal;
                        tipodecomision.innerHTML=+valcomenviar+" USD";
                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;USD";
                        valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valusdareal)).toFixed(2);
                        tipototalrecibe.value=valtotalrecibe;
                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                        tcambio.value=valusdareal;
                        tcomisi.value=valcomenviar;
                        timpues.value=valimpuestos;
                        ttotale.value=valtotalenviar;
                        tenviar.value=valmonto;
                        trecibe.value=valtotalrecibe;
                        tmoneda.value='Dolar a Real';
                        btnsiguiente.style.display='block';
                    }else{
                        if(valmonto<300){
                            comision=co200a299usdabrl.value;
                            errorenvio.style.display='none';
                            valcomision=(parseFloat(comision)*100).toFixed(2);
                            valcomenviar=parseFloat(valmonto)*parseFloat(comision);
                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                            valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;USD";
                            tipodecambio.innerHTML=valusdareal+"&nbsp;USD";
                            tipodecomision.innerHTML=+valcomenviar+" USD";
                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;USD";
                            valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valusdareal)).toFixed(2);
                            tipototalrecibe.value=valtotalrecibe;
                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                            tcambio.value=valusdareal;
                            tcomisi.value=valcomenviar;
                            timpues.value=valimpuestos;
                            ttotale.value=valtotalenviar;
                            tenviar.value=valmonto;
                            trecibe.value=valtotalrecibe;
                            tmoneda.value='Dolar a Real';
                            btnsiguiente.style.display='block';
                        }else{
                            if(valmonto<500){
                                comision=co300a499usdabrl.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;USD";
                                tipodecambio.innerHTML=valusdareal;
                                tipodecomision.innerHTML=+valcomenviar+" USD";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;USD";
                                valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valusdareal)).toFixed(2);
                                tipototalrecibe.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valusdareal;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=valmonto;
                                trecibe.value=valtotalrecibe;
                                tmoneda.value='Dolar a Real';
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<1000){
                                    comision=co500a999usdabrl.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;USD";
                                    tipodecambio.innerHTML=valusdareal;
                                    tipodecomision.innerHTML=+valcomenviar+" USD";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;USD";
                                    valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valusdareal)).toFixed(2);
                                    tipototalrecibe.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valusdareal;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=valmonto;
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Dolar a Real';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<3000){
                                        //comision=comision1000a5000.value;
                                        //comision=co1000a5000usdbrl;
                                        comision=co1000a2999usdabrl.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;USD";
                                        tipodecambio.innerHTML=valusdareal;
                                        tipodecomision.innerHTML=+valcomenviar+" USD";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;USD";
                                        valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valusdareal)).toFixed(2);
                                        tipototalrecibe.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valusdareal;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=valmonto;
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Dolar a Real';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<=5000){
                                            //comision=comision1000a5000.value;
                                            //comision=co1000a5000usdbrl;
                                            comision=co3000a5000usdabrl.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;USD";
                                            tipodecambio.innerHTML=valusdareal;
                                            tipodecomision.innerHTML=+valcomenviar+" USD";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;USD";
                                            valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valusdareal)).toFixed(2);
                                            tipototalrecibe.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valusdareal;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=valmonto;
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Dolar a Real';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            errorenvio.style.display='block';
                                            errorenvio.innerHTML='Ingrese Monto menor a 5000';
                                            tipodeimpuestos.innerHTML="0.00";
                                            tipodecambio.innerHTML="0.00";
                                            tipodecomision.innerHTML="0.00";
                                            tipototalenviar.innerHTML="0.00";
                                            tipototalrecibe.value="0.00";
                                            numcomision.innerHTML="0.00";
                                            tcambio.value=0;
                                            tcomisi.value=0;
                                            timpues.value=0;
                                            ttotale.value=0;
                                            tenviar.value=0;
                                            trecibe.value=0;
                                            tmoneda.value='Dolar a Real';
                                            btnsiguiente.style.display='none';
                                        }
                                    }
                                }
                            }
                        }        
                    }
                }
                //alert(valeletipmonenv);
                break;
            case('brlpen'):
                eletipmonenv.value=e;
                enviomoneda.innerHTML=`
                    <ul class="nav">
                        <li class="fontbebas">
                             <div onclick="calculadora.resultado('brlpen')" style="display:flex;justify-content: flex-end;">
                                <img src="{{url_for('static',filename='img/bra.png')}}" style="width:50px;height:35px;">
                                <div style="padding:10px;">&nbsp;BRL Brasil</div>
                                <div style="width: 0;height: 0;border-right: 10px solid transparent;border-top: 10px solid transparent;border-left: 10px solid transparent;border-bottom: 10px solid #f0ad4e;transform: rotate(180deg); "></div>
                            </div>
                            <ul>
                                <li>
                                    <div onclick="calculadora.resultado('penbrl')" style="display:flex;justify-content: flex-end;">
                                        <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                        <div style="padding:10px;">&nbsp;PEN Perú</div>
                                    </div>
                                </li>
                                <li>
                                    <div onclick="calculadora.resultado('usdbrl')" style="display:flex;justify-content: flex-end;">
                                        <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                        <div style="padding:10px;">&nbsp;USD PEN</div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                `;
                recibemoneda.innerHTML=`
                    <ul class="nav">
                        <li class="fontbebas">
                             <div onclick="calculadora.resultado('brlpen')" style="display:flex;justify-content: flex-end;">
                                <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                <div style="padding:10px;">&nbsp;PEN Perú</div>
                                <div style="width: 0;height: 0;border-right: 10px solid transparent;border-top: 10px solid transparent;border-left: 10px solid transparent;border-bottom: 10px solid #f0ad4e;transform: rotate(180deg); "></div>
                            </div>
                            <ul>
                                <li>
                                    <div onclick="calculadora.resultado('brlusd')" style="display:flex;justify-content: flex-end;">
                                        <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                        <div style="padding:10px;">&nbsp;USD PEN</div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                `;
                var valmonto=inputmontoenviar.value;
                if(valmonto<100){
                    errorenvio.style.display='block';
                    errorenvio.innerHTML='Ingrese Monto mayor a 100';
                    tipodeimpuestos.innerHTML="0.00";
                    tipodecambio.innerHTML="0.00";
                    tipodecomision.innerHTML="0.00";
                    tipototalenviar.innerHTML="0.00";
                    tipototalrecibe.value="0.00";
                    numcomision.innerHTML="0.00";
                    tcambio.value=0;
                    tcomisi.value=0;
                    timpues.value=0;
                    ttotale.value=0;
                    tenviar.value=0;
                    trecibe.value=0;
                    tmoneda.value='Real a Sol';
                    btnsiguiente.style.display='none';
                }else{
                    if(valmonto<200){
                        comision=co100a199brlapen.value;
                        errorenvio.style.display='none';
                        valcomision=(parseFloat(comision)*100).toFixed(2);
                        valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);
                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                        valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                        tipodecambio.innerHTML=valrealapen;
                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                        valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealapen)).toFixed(2);
                        tipototalrecibe.value=valtotalrecibe;
                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                        tcambio.value=valrealapen;
                        tcomisi.value=valcomenviar;
                        timpues.value=valimpuestos;
                        ttotale.value=valtotalenviar;
                        tenviar.value=valmonto;
                        trecibe.value=valtotalrecibe;
                        tmoneda.value='Real a Sol';
                        btnsiguiente.style.display='block';
                    }else{
                        if(valmonto<300){
                            comision=co200a299brlapen.value;
                            errorenvio.style.display='none';
                            valcomision=(parseFloat(comision)*100).toFixed(2);
                            valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);
                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                            valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                            tipodecambio.innerHTML=valrealapen;
                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                            valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealapen)).toFixed(2);
                            tipototalrecibe.value=valtotalrecibe;
                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                            tcambio.value=valrealapen;
                            tcomisi.value=valcomenviar;
                            timpues.value=valimpuestos;
                            ttotale.value=valtotalenviar;
                            tenviar.value=valmonto;
                            trecibe.value=valtotalrecibe;
                            tmoneda.value='Real a Sol';
                            btnsiguiente.style.display='block';
                        }else{
                            if(valmonto<500){
                                comision=co300a499brlapen.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                tipodecambio.innerHTML=valrealapen;
                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealapen)).toFixed(2);
                                tipototalrecibe.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valrealapen;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=valmonto;
                                trecibe.value=valtotalrecibe;
                                tmoneda.value='Real a Sol';
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<1000){
                                    comision=co500a999brlapen.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valrealapen;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealapen)).toFixed(2);
                                    tipototalrecibe.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valrealapen;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=valmonto;
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Real a Sol';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<3000){
                                        comision=co1000a2999brlapen.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealapen;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealapen)).toFixed(2);
                                        tipototalrecibe.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealapen;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=valmonto;
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Real a Sol';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<=5000){
                                            comision=co3000a5000brlapen.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(2);
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealapen;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealapen)).toFixed(2);
                                            tipototalrecibe.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealapen;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=valmonto;
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Real a Sol';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            errorenvio.style.display='block';
                                            errorenvio.innerHTML='Ingrese Monto menor a 5000';
                                            tipodeimpuestos.innerHTML="0.00";
                                            tipodecambio.innerHTML="0.00";
                                            tipodecomision.innerHTML="0.00";
                                            tipototalenviar.innerHTML="0.00";
                                            tipototalrecibe.value="0.00";
                                            numcomision.innerHTML="0.00";
                                            tcambio.value=0;
                                            tcomisi.value=0;
                                            timpues.value=0;
                                            ttotale.value=0;
                                            tenviar.value=0;
                                            trecibe.value=0;
                                            tmoneda.value='Real a Sol';
                                            btnsiguiente.style.display='none';
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                //alert(valeletipmonenv);
                break;
            case('brlusd'):
                eletipmonenv.value=e;
                enviomoneda.innerHTML=`
                    <ul class="nav">
                        <li class="fontbebas">
                             <div onclick="calculadora.resultado('brlpen')" style="display:flex;justify-content: flex-end;">
                                <img src="{{url_for('static',filename='img/bra.png')}}" style="width:50px;height:35px;">
                                <div style="padding:10px;">&nbsp;BRL Brasil</div>
                                <div style="width: 0;height: 0;border-right: 10px solid transparent;border-top: 10px solid transparent;border-left: 10px solid transparent;border-bottom: 10px solid #f0ad4e;transform: rotate(180deg); "></div>
                            </div>
                            <ul>
                                <li>
                                    <div onclick="calculadora.resultado('penbrl')" style="display:flex;justify-content: flex-end;">
                                        <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                        <div style="padding:10px;">&nbsp;PEN Perú</div>
                                        <div style="width: 0;height: 0;border-right: 10px solid transparent;border-top: 10px solid transparent;border-left: 10px solid transparent;border-bottom: 10px solid #f0ad4e;transform: rotate(180deg); "></div>
                                    </div>
                                </li>
                                <li>
                                    <div onclick="calculadora.resultado('usdbrl')" style="display:flex;justify-content: flex-end;">
                                        <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                        <div style="padding:10px;">&nbsp;USD PEN</div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                `;
                recibemoneda.innerHTML=`
                    <ul class="nav">
                        <li class="fontbebas">
                            <div onclick="calculadora.resultado('brlusd')" style="display:flex;justify-content: flex-end;">
                                <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                <div style="padding:10px;">&nbsp;USD PEN</div>
                                <div style="width: 0;height: 0;border-right: 10px solid transparent;border-top: 10px solid transparent;border-left: 10px solid transparent;border-bottom: 10px solid #f0ad4e;transform: rotate(180deg); "></div>

                            </div>
                            <ul>
                                <li>
                                    <div onclick="calculadora.resultado('brlpen')" style="display:flex;justify-content: flex-end;">
                                        <img src="{{url_for('static',filename='img/pen.png')}}" style="width:50px;height:35px;">
                                        <div style="padding:10px;">&nbsp;PEN Perú</div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                `;
                var valmonto=inputmontoenviar.value;
                if(valmonto<100){
                    errorenvio.style.display='block';
                    errorenvio.innerHTML='Ingrese Monto mayor a 100';
                    tipodeimpuestos.innerHTML="0.00";
                    tipodecambio.innerHTML="0.00";
                    tipodecomision.innerHTML="0.00";
                    tipototalenviar.innerHTML="0.00";
                    tipototalrecibe.value="0.00";
                    numcomision.innerHTML="0.00";
                    tcambio.value=0;
                    tcomisi.value=0;
                    timpues.value=0;
                    ttotale.value=0;
                    tenviar.value=0;
                    trecibe.value=0;
                    tmoneda.value='Real a Dolar';
                    btnsiguiente.style.display='none';
                }else{
                    if(valmonto<200){
                        comision=co100a199brlausd.value;
                        errorenvio.style.display='none';
                        valcomision=(parseFloat(comision)*100).toFixed(2);
                        valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                        valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                        tipodecambio.innerHTML=valrealausd;
                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                        valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealausd)).toFixed(2);
                        tipototalrecibe.value=valtotalrecibe;
                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                        tcambio.value=valrealausd;
                        tcomisi.value=valcomenviar;
                        timpues.value=valimpuestos;
                        ttotale.value=valtotalenviar;
                        tenviar.value=valmonto;
                        trecibe.value=valtotalrecibe;
                        tmoneda.value='Real a Dolar';
                        btnsiguiente.style.display='block';
                    }else{
                        if(valmonto<300){
                            comision=co200a299brlausd.value;
                            errorenvio.style.display='none';
                            valcomision=(parseFloat(comision)*100).toFixed(2);
                            valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                            valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                            tipodecambio.innerHTML=valrealausd;
                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                            valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealausd)).toFixed(2);
                            tipototalrecibe.value=valtotalrecibe;
                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                            tcambio.value=valrealausd;
                            tcomisi.value=valcomenviar;
                            timpues.value=valimpuestos;
                            ttotale.value=valtotalenviar;
                            tenviar.value=valmonto;
                            trecibe.value=valtotalrecibe;
                            tmoneda.value='Real a Dolar';
                            btnsiguiente.style.display='block';
                        }else{
                            if(valmonto<500){
                                comision=co300a499brlausd.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                tipodecambio.innerHTML=valrealausd;
                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealausd)).toFixed(2);
                                tipototalrecibe.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valrealausd;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=valmonto;
                                trecibe.value=valtotalrecibe;
                                tmoneda.value='Real a Dolar';
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<1000){
                                    comision=co500a999brlausd.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valrealausd;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealausd)).toFixed(2);
                                    tipototalrecibe.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valrealausd;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=valmonto;
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Real a Dolar';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<3000){
                                        //comision=comision1000a5000.value;
                                        //comision=co1000a5000brlusd;
                                        comision=co1000a2999brlausd.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealausd;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealausd)).toFixed(2);
                                        tipototalrecibe.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealausd;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=valmonto;
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Real a Dolar';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<=5000){
                                            //comision=comision1000a5000.value;
                                            //comision=co1000a5000brlusd;
                                            comision=co3000a5000brlausd.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            valcomenviar=(parseFloat(valmonto)*parseFloat(comision)).toFixed(3);
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=parseFloat(valmonto)-parseFloat(valtotalcomimp);
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealausd;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=(parseFloat(valtotalenviar)*parseFloat(valrealausd)).toFixed(2);
                                            tipototalrecibe.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealausd;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=valmonto;
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Real a Dolar';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            errorenvio.style.display='block';
                                            errorenvio.innerHTML='Ingrese Monto menor a 5000';
                                            tipodeimpuestos.innerHTML="0.00";
                                            tipodecambio.innerHTML="0.00";
                                            tipodecomision.innerHTML="0.00";
                                            tipototalenviar.innerHTML="0.00";
                                            tipototalrecibe.value="0.00";
                                            numcomision.innerHTML="0.00";
                                            tcambio.value=valrealausd;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=valtotalenviar;
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Real a Dolar';
                                            btnsiguiente.style.display='none';
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            break;
        }
    },
    envio:function(){
        ventanacalculadora.style.display='none';
        var tipocamb=tcambio.value;
        var tipocomi=tcomisi.value;
        var tipoimpu=timpues.value;
        var tipotota=ttotale.value;
        var tipoenvi=tenviar.value;
        var tiporeci=trecibe.value;
        cantidadorigen.innerHTML=tipoenvi;
        cantidadcambio.innerHTML=tipocamb;
        cantidadcomision.innerHTML=tipocomi;
        cantidadimpuestos.innerHTML=tipoimpu;
        cantidadenviar.innerHTML=tipotota;
        cantidadrecibe.innerHTML=tiporeci;
        btnsiguiente.style.display='block';
        
        //alert('tipo de cambio'+tipocamb+'\n comision'+tipocomi+'\n impuesto'+tipoimpu+'\n total'+tipotota+'\n enviar'+tipoenvi+'\n recibe'+tiporeci);
    },
    whatsapp:function(){
        if(inputmontoenviar.value<100){
            errorenvio.style.display='block';
            errorenvio.innerHTML='Ingrese Monto mayor a 100';
        }else{
            if(inputmontoenviar.value>5000){
                errorenvio.style.display='block';
                errorenvio.innerHTML='Ingrese Monto menor a 5000';
            }else{
                errorenvio.style.display='none';
                var valeletipmonenv=eletipmonenv.value;
                var valtipodemoneaenvioss=tmoneda.value;
                switch(valtipodemoneaenvioss){
                        case('Real a Dolar'):
                            window.open('https://api.whatsapp.com/send/?phone=51966991933&text=Monto%20Ingresado:%20'+tenviar.value+'%20BRL%0ATipo%20de%20Cambio:%20'+tcambio.value+'%20%0AComisión:%20'+tcomisi.value+'%20BRL%0AImpuestos:%20'+timpues.value+'%20BRL%0ATotal%20a%20Enviar:%20'+ttotale.value+'%20BRL%0ARecibe:%20'+trecibe.value+'%20USD','_blank');
                            break;
                        case('Sol a Real'):
                            window.open('https://api.whatsapp.com/send/?phone=51966991933&text=Monto%20Ingresado:%20'+tenviar.value+'%20PEN%0ATipo%20de%20Cambio:%20'+tcambio.value+'%20%0AComisión:%20'+tcomisi.value+'%20PEN%0AImpuestos:%20'+timpues.value+'%20PEN%0ATotal%20a%20Enviar:%20'+ttotale.value+'%20PEN%0ARecibe:%20'+trecibe.value+'%20BRL','_blank');
                            break;
                        case('Dolar a Real'):
                            window.open('https://api.whatsapp.com/send/?phone=51966991933&text=Monto%20Ingresado:%20'+tenviar.value+'%20USD%0ATipo%20de%20Cambio:%20'+tcambio.value+'%20%0AComisión:%20'+tcomisi.value+'%20USD%0AImpuestos:%20'+timpues.value+'%20USD%0ATotal%20a%20Enviar:%20'+ttotale.value+'%20USD%0ARecibe:%20'+trecibe.value+'%20BRL','_blank');
                            break;
                        case('Real a Sol'):
                            window.open('https://api.whatsapp.com/send/?phone=51966991933&text=Monto%20Ingresado:%20'+tenviar.value+'%20BRL%0ATipo%20de%20Cambio:%20'+tcambio.value+'%20%0AComisión:%20'+tcomisi.value+'%20BRL%0AImpuestos:%20'+timpues.value+'%20BRL%0ATotal%20a%20Enviar:%20'+ttotale.value+'%20BRL%0ARecibe:%20'+trecibe.value+'%20PEN','_blank');
                            break;
                        case('Real a Dolar'):
                            window.open('https://api.whatsapp.com/send/?phone=51966991933&text=Monto%20Ingresado:%20'+tenviar.value+'%20BRL%0ATipo%20de%20Cambio:%20'+tcambio.value+'%20%0AComisión:%20'+tcomisi.value+'%20BRL%0AImpuestos:%20'+timpues.value+'%20BRL%0ATotal%20a%20Enviar:%20'+ttotale.value+'%20BRL%0ARecibe:%20'+trecibe.value+'%20USD','_blank');
                            break;
                }
                //alert('tipo de cambio: '+tcambio.value+'\nComision: '+tcomisi.value+'\nImpuesto: '+timpues.value+'\nTotal a Enviar: '+ttotale.value+'\nMonto Ingresado: '+tenviar.value+'\nRecibe: '+trecibe.value+'\nMoneda'+valtipodemoneaenvioss);

                //Envias:BRL200(brasil) tipo de cambio: USD 1=0.201 RECIBE USD 38.90(Perú) comision de envio BRL 5.50 Impuestos 0.99 Subtotal BRL 6.49 Total a covertir BRL 193.511
            }
        }
    },
    abajaso:function(){
        posiciona.value='abajo';
        var resultadoinicial;
        var valabajo=tipototalrecibe.value;
        var valeletipmonenv=eletipmonenv.value;
        var soladol=document.getElementById('soladol').value;
        var solareal=document.getElementById('solareal').value;
        var usdasol=document.getElementById('usdasol').value;
        var usdareal=document.getElementById('usdareal').value;
        var realapen=document.getElementById('realapen').value;
        var realausd=document.getElementById('realausd').value;
        var valsoldol=parseFloat(soladol).toFixed(3);
        var valsolrea=parseFloat(solareal).toFixed(3);
        var valusdasol=parseFloat(usdasol).toFixed(3);
        var valusdareal=parseFloat(usdareal).toFixed(3);
        var valrealapen=parseFloat(realapen).toFixed(3);
        var valrealausd=parseFloat(realausd).toFixed(3);
        switch(valeletipmonenv){
            case('penbrl'):
                var valmontoinit=inputmontoenviar.value;
                var valmonto=valabajo;
                if(valmonto<0){
                    errorenvio.style.display='block';
                    errorenvio.innerHTML='Ingrese Monto mayor a 100';
                    tipodeimpuestos.innerHTML="0.00";
                    tipodecambio.innerHTML="0.00";
                    tipodecomision.innerHTML="0.00";
                    tipototalenviar.innerHTML="0.00";
                    tipototalrecibe.value="0.00";
                    numcomision.innerHTML="0.00";
                    tcambio.value=0;
                    tcomisi.value=0;
                    timpues.value=0;
                    ttotale.value=0;
                    tenviar.value=0;
                    trecibe.value=0;
                    tmoneda.value='Real a Sol';
                    btnsiguiente.style.display='none';
                }else{
                    if(valmonto<200){
                        if(valmonto<200){
                            comision=co100a199penabrl.value;
                            inversa=in100a199penabrl.value;
                            //inversa=inversacomision100a199.value;
                            errorenvio.style.display='none';
                            valcomision=(parseFloat(comision)*100).toFixed(2);
                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                            tipodecambio.innerHTML=valsolrea;
                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                            inputmontoenviar.value=valtotalrecibe;
                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                            tcambio.value=valsolrea;
                            tcomisi.value=valcomenviar;
                            timpues.value=valimpuestos;
                            ttotale.value=valtotalenviar;
                            tenviar.value=resultadoinicial;//modificar
                            //tmoneda.value='Real a Sol';
                            //trecibe.value=valtotalrecibe;
                            tmoneda.value='Sol a Real';
                            trecibe.value=tipototalrecibe.value;
                            btnsiguiente.style.display='block';
                        }else{
                            if(valmonto<300){
                                comision=co200a299penabrl.value;
                                inversa=in200a299penabrl.value;
                                //inversa=inversacomision200a299.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                tipodecambio.innerHTML=valsolrea;
                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                inputmontoenviar.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valsolrea;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=resultadoinicial;//modificar
                                //tmoneda.value='Real a Sol';
                                //trecibe.value=valtotalrecibe;
                                tmoneda.value='Sol a Real';
                                trecibe.value=tipototalrecibe.value;
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<500){
                                    comision=co300a499penabrl.value;
                                    inversa=in300a499penabrl.value;
                                    //inversa=inversacomision300a399.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                    tipodecambio.innerHTML=valsolrea;
                                    tipodecomision.innerHTML=+valcomenviar+" PEN";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valsolrea;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    //tmoneda.value='Real a Sol';
                                    //trecibe.value=valtotalrecibe;
                                    tmoneda.value='Sol a Real';
                                    trecibe.value=tipototalrecibe.value;
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<1000){
                                        comision=co500a999penabrl.value;
                                        inversa=in500a999penabrl.value;
                                        //inversa=inversacomision400a999.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                        tipodecambio.innerHTML=valsolrea;
                                        tipodecomision.innerHTML=+valcomenviar+" PEN";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valsolrea;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        //tmoneda.value='Real a Sol';
                                        //trecibe.value=valtotalrecibe;
                                        tmoneda.value='Sol a Real';
                                        trecibe.value=tipototalrecibe.value;
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<3000){
                                            comision=co1000a2999penabrl.value;
                                            inversa=in1000a2999penabrl.value;
                                            //inversa=comision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                            tipodecambio.innerHTML=valsolrea;
                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valsolrea;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Real a Sol';
                                            //trecibe.value=valtotalrecibe;
                                            tmoneda.value='Sol a Real';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<=5000){
                                            comision=co3000a5000penabrl.value;
                                            inversa=in3000a5000penabrl.value;
                                            //inversa=comision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                            tipodecambio.innerHTML=valsolrea;
                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valsolrea;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Real a Sol';
                                            //trecibe.value=valtotalrecibe;
                                            tmoneda.value='Sol a Real';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            comision=co3000a5000penabrl.value;
                                            inversa=in3000a5000penabrl.value;
                                            //inversa=inversacomision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                            tipodecambio.innerHTML=valsolrea;
                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valsolrea;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Real a Sol';
                                            //trecibe.value=valtotalrecibe;
                                            tmoneda.value='Sol a Real';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }
                                        }
                                    }
                                }
                            }
                        }
                    }else{
                        if(valmonto<300){
                            if(valmonto<200){
                                comision=co100a199penabrl.value;
                                inversa=in100a199penabrl.value;
                                //inversa=inversacomision100a199.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                tipodecambio.innerHTML=valsolrea;
                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                inputmontoenviar.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valsolrea;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=resultadoinicial;//modificar
                                //tmoneda.value='Real a Sol';
                                //trecibe.value=valtotalrecibe;
                                tmoneda.value='Sol a Real';
                                trecibe.value=tipototalrecibe.value;
                                btnsiguiente.style.display='block';
                        }else{
                            if(valmonto<300){
                                comision=co200a299penabrl.value;
                                inversa=in200a299penabrl.value;
                                //inversa=inversacomision200a299.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                tipodecambio.innerHTML=valsolrea;
                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                inputmontoenviar.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valsolrea;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=resultadoinicial;//modificar
                                //tmoneda.value='Real a Sol';
                                //trecibe.value=valtotalrecibe;
                                tmoneda.value='Sol a Real';
                                trecibe.value=tipototalrecibe.value;
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<500){
                                    comision=co300a499penabrl.value;
                                    inversa=in300a499penabrl.value;
                                    //inversa=inversacomision300a399.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                    tipodecambio.innerHTML=valsolrea;
                                    tipodecomision.innerHTML=+valcomenviar+" PEN";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valsolrea;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    //tmoneda.value='Real a Sol';
                                    //trecibe.value=valtotalrecibe;
                                    tmoneda.value='Sol a Real';
                                    trecibe.value=tipototalrecibe.value;
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<1000){
                                        comision=co500a999penabrl.value;
                                        inversa=in500a999penabrl.value;
                                        //inversa=inversacomision400a999.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                        tipodecambio.innerHTML=valsolrea;
                                        tipodecomision.innerHTML=+valcomenviar+" PEN";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valsolrea;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        //tmoneda.value='Real a Sol';
                                        //trecibe.value=valtotalrecibe;
                                        tmoneda.value='Sol a Real';
                                        trecibe.value=tipototalrecibe.value;
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<3000){
                                            comision=co1000a2999penabrl.value;
                                            inversa=in1000a2999penabrl.value;
                                            //inversa=inversacomision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                            tipodecambio.innerHTML=valsolrea;
                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valsolrea;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Real a Sol';
                                            //trecibe.value=valtotalrecibe;
                                            tmoneda.value='Sol a Real';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<=5000){
                                                comision=co3000a5000penabrl.value;
                                                inversa=in3000a5000penabrl.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                tipodecambio.innerHTML=valsolrea;
                                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valsolrea;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Real a Sol';
                                                //trecibe.value=valtotalrecibe;
                                                tmoneda.value='Sol a Real';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                comision=co3000a5000penabrl.value;
                                                inversa=in3000a5000penabrl.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                tipodecambio.innerHTML=valsolrea;
                                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valsolrea;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Real a Sol';
                                                //trecibe.value=valtotalrecibe;
                                                tmoneda.value='Sol a Real';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }
                                        }
                                    }
                                }
                            }
                        } 
                        }else{
                            if(valmonto<500){
                                if(valmonto<200){
                                    comision=co100a199penabrl.value;
                                    inversa=in100a199penabrl.value;
                                    //inversa=inversacomision100a199.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                    tipodecambio.innerHTML=valsolrea;
                                    tipodecomision.innerHTML=+valcomenviar+" PEN";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valsolrea;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    //tmoneda.value='Real a Sol';
                                    //trecibe.value=valtotalrecibe;
                                    tmoneda.value='Sol a Real';
                                    trecibe.value=tipototalrecibe.value;
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<300){
                                        comision=co200a299penabrl.value;
                                        inversa=in200a299penabrl.value;
                                        //inversa=inversacomision200a299.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                        tipodecambio.innerHTML=valsolrea;
                                        tipodecomision.innerHTML=+valcomenviar+" PEN";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valsolrea;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        //tmoneda.value='Real a Sol';
                                        //trecibe.value=valtotalrecibe;
                                        tmoneda.value='Sol a Real';
                                        trecibe.value=tipototalrecibe.value;
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<500){
                                            comision=co300a499penabrl.value;
                                            inversa=in300a499penabrl.value;
                                            //inversa=inversacomision300a399.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                            tipodecambio.innerHTML=valsolrea;
                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valsolrea;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Real a Sol';
                                            //trecibe.value=valtotalrecibe;
                                            tmoneda.value='Sol a Real';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<1000){
                                                comision=co500a999penabrl.value;
                                                inversa=in500a999penabrl.value;
                                                //inversa=inversacomision400a999.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                tipodecambio.innerHTML=valsolrea;
                                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valsolrea;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Real a Sol';
                                                //trecibe.value=valtotalrecibe;
                                                tmoneda.value='Sol a Real';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<3000){
                                                    comision=co1000a2999penabrl.value;
                                                    inversa=in1000a2999penabrl.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                    tipodecambio.innerHTML=valsolrea;
                                                    tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valsolrea;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Real a Sol';
                                                    //trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Sol a Real';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<=5000){
                                                        comision=co3000a5000penabrl.value;
                                                        inversa=in3000a5000penabrl.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                        tipodecambio.innerHTML=valsolrea;
                                                        tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valsolrea;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        //tmoneda.value='Real a Sol';
                                                        //trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Sol a Real';
                                                        trecibe.value=tipototalrecibe.value;
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        comision=co3000a5000penabrl.value;
                                                        inversa=in3000a5000penabrl.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valsolrea;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valsolrea;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        tmoneda.value='Real a Sol';
                                                        trecibe.value=valtotalrecibe;
                                                        btnsiguiente.style.display='block';
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }else{
                                if(valmonto<1000){
                                    if(valmonto<200){
                                        comision=co100a199penabrl.value;
                                        inversa=in100a199penabrl.value;
                                        //inversa=inversacomision100a199.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                        tipodecambio.innerHTML=valsolrea;
                                        tipodecomision.innerHTML=+valcomenviar+" PEN";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valsolrea;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        //tmoneda.value='Real a Sol';
                                        //trecibe.value=valtotalrecibe;
                                        tmoneda.value='Sol a Real';
                                        trecibe.value=tipototalrecibe.value;
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<300){
                                            comision=co200a299penabrl.value;
                                            inversa=in200a299penabrl.value;
                                            //inversa=inversacomision200a299.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                            tipodecambio.innerHTML=valsolrea;
                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valsolrea;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Real a Sol';
                                            //trecibe.value=valtotalrecibe;
                                            tmoneda.value='Sol a Real';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<500){
                                                comision=co300a499penabrl.value;
                                                inversa=in300a499penabrl.value;
                                                //inversa=inversacomision300a399.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                tipodecambio.innerHTML=valsolrea;
                                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valsolrea;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Real a Sol';
                                                //trecibe.value=valtotalrecibe;
                                                tmoneda.value='Sol a Real';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<1000){
                                                    comision=co500a999penabrl.value;
                                                    inversa=in500a999penabrl.value;
                                                    //inversa=inversacomision400a999.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                    tipodecambio.innerHTML=valsolrea;
                                                    tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valsolrea;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Real a Sol';
                                                    //trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Sol a Real';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<3000){
                                                        comision=co1000a2999penabrl.value;
                                                        inversa=in1000a2999penabrl.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                        tipodecambio.innerHTML=valsolrea;
                                                        tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valsolrea;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        //tmoneda.value='Real a Sol';
                                                        //trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Sol a Real';
                                                        trecibe.value=tipototalrecibe.value;
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<=5000){
                                                            comision=co3000a5000penabrl.value;
                                                            inversa=in3000a5000penabrl.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                            tipodecambio.innerHTML=valsolrea;
                                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valsolrea;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            //tmoneda.value='Real a Sol';
                                                            //trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Sol a Real';
                                                            trecibe.value=tipototalrecibe.value;
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            comision=co3000a5000penabrl.value;
                                                            inversa=in3000a5000penabrl.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                            tipodecambio.innerHTML=valsolrea;
                                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valsolrea;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            //tmoneda.value='Real a Sol';
                                                            //trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Sol a Real';
                                                            trecibe.value=tipototalrecibe.value;
                                                            btnsiguiente.style.display='block';
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }else{
                                    if(valmonto<3000){
                                        if(valmonto<200){
                                            comision=co100a199penabrl.value;
                                            inversa=in100a199penabrl.value;
                                            //inversa=inversacomision100a199.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                            tipodecambio.innerHTML=valsolrea;
                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valsolrea;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Real a Sol';
                                            //trecibe.value=valtotalrecibe;
                                            tmoneda.value='Sol a Real';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<300){
                                                comision=co200a299penabrl.value;
                                                inversa=in200a299penabrl.value;
                                                //inversa=inversacomision200a299.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                tipodecambio.innerHTML=valsolrea;
                                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valsolrea;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Real a Sol';
                                                //trecibe.value=valtotalrecibe;
                                                tmoneda.value='Sol a Real';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<500){
                                                    comision=co300a499penabrl.value;
                                                    inversa=in300a499penabrl.value;
                                                    //inversa=inversacomision300a399.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                    tipodecambio.innerHTML=valsolrea;
                                                    tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valsolrea;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Real a Sol';
                                                    //trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Sol a Real';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<1000){
                                                        comision=co500a999penabrl.value;
                                                        inversa=in500a999penabrl.value;
                                                        //inversa=inversacomision400a999.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                        tipodecambio.innerHTML=valsolrea;
                                                        tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valsolrea;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        //tmoneda.value='Real a Sol';
                                                        //trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Sol a Real';
                                                        trecibe.value=tipototalrecibe.value;
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<3000){
                                                            comision=co1000a2999penabrl.value;
                                                            inversa=in1000a2999penabrl.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                            tipodecambio.innerHTML=valsolrea;
                                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valsolrea;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            //tmoneda.value='Real a Sol';
                                                            //trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Sol a Real';
                                                            trecibe.value=tipototalrecibe.value;
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            if(valmonto<=5000){
                                                                comision=co3000a5000penabrl.value;
                                                                inversa=in3000a5000penabrl.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                                tipodecambio.innerHTML=valsolrea;
                                                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valsolrea;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                //tmoneda.value='Real a Sol';
                                                                //trecibe.value=valtotalrecibe;
                                                                tmoneda.value='Sol a Real';
                                                                trecibe.value=tipototalrecibe.value;
                                                                btnsiguiente.style.display='block';
                                                            }else{
                                                                comision=co3000a5000penabrl.value;
                                                                inversa=in3000a5000penabrl.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                                tipodecambio.innerHTML=valsolrea;
                                                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valsolrea;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                //tmoneda.value='Real a Sol';
                                                                //trecibe.value=valtotalrecibe;
                                                                tmoneda.value='Sol a Real';
                                                                trecibe.value=tipototalrecibe.value;
                                                                btnsiguiente.style.display='block';
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }else{
                                        if(valmonto<=5000){
                                            if(valmonto<200){
                                                comision=co100a199penabrl.value;
                                                inversa=in100a199penabrl.value;
                                                //inversa=inversacomision100a199.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                tipodecambio.innerHTML=valsolrea;
                                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valsolrea;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Real a Sol';
                                                //trecibe.value=valtotalrecibe;
                                                tmoneda.value='Sol a Real';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<300){
                                                    comision=co200a299penabrl.value;
                                                    inversa=in200a299penabrl.value;
                                                    //inversa=inversacomision200a299.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                    tipodecambio.innerHTML=valsolrea;
                                                    tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valsolrea;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Real a Sol';
                                                    //trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Sol a Real';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<500){
                                                        comision=co300a499penabrl.value;
                                                        inversa=in300a499penabrl.value;
                                                        //inversa=inversacomision300a399.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                        tipodecambio.innerHTML=valsolrea;
                                                        tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valsolrea;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        //tmoneda.value='Real a Sol';
                                                        //trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Sol a Real';
                                                        trecibe.value=tipototalrecibe.value;
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<1000){
                                                            comision=co500a999penabrl.value;
                                                            inversa=in500a999penabrl.value;
                                                            //inversa=inversacomision400a999.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                            tipodecambio.innerHTML=valsolrea;
                                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valsolrea;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            //tmoneda.value='Real a Sol';
                                                            //trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Sol a Real';
                                                            trecibe.value=tipototalrecibe.value;
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            if(valmonto<3000){
                                                                comision=co1000a2999penabrl.value;
                                                                inversa=in1000a2999penabrl.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                                tipodecambio.innerHTML=valsolrea;
                                                                tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valsolrea;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                //tmoneda.value='Real a Sol';
                                                                //trecibe.value=valtotalrecibe;
                                                                tmoneda.value='Sol a Real';
                                                                trecibe.value=tipototalrecibe.value;
                                                                btnsiguiente.style.display='block';
                                                            }else{
                                                                if(valmonto<=5000){
                                                                    comision=co3000a5000penabrl.value;
                                                                    inversa=in3000a5000penabrl.value;
                                                                    //inversa=inversacomision1000a5000.value;
                                                                    errorenvio.style.display='none';
                                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                                    tipodecambio.innerHTML=valsolrea;
                                                                    tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                    inputmontoenviar.value=valtotalrecibe;
                                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                    tcambio.value=valsolrea;
                                                                    tcomisi.value=valcomenviar;
                                                                    timpues.value=valimpuestos;
                                                                    ttotale.value=valtotalenviar;
                                                                    tenviar.value=resultadoinicial;//modificar
                                                                    //tmoneda.value='Real a Sol';
                                                                    //trecibe.value=valtotalrecibe;
                                                                    tmoneda.value='Sol a Real';
                                                                    trecibe.value=tipototalrecibe.value;
                                                                    btnsiguiente.style.display='block';
                                                                }else{
                                                                    comision=co3000a5000penabrl.value;
                                                                    inversa=in3000a5000penabrl.value;
                                                                    //inversa=inversacomision1000a5000.value;
                                                                    errorenvio.style.display='none';
                                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                                                    tipodecambio.innerHTML=valsolrea;
                                                                    tipodecomision.innerHTML=+valcomenviar+" PEN";
                                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                    inputmontoenviar.value=valtotalrecibe;
                                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                    tcambio.value=valsolrea;
                                                                    tcomisi.value=valcomenviar;
                                                                    timpues.value=valimpuestos;
                                                                    ttotale.value=valtotalenviar;
                                                                    tenviar.value=resultadoinicial;//modificar
                                                                    //tmoneda.value='Real a Sol';
                                                                    //trecibe.value=valtotalrecibe;
                                                                    tmoneda.value='Sol a Real';
                                                                    trecibe.value=tipototalrecibe.value;
                                                                    btnsiguiente.style.display='block';
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }else{
                                            comision=co3000a5000penabrl.value;
                                            inversa=in3000a5000penabrl.value;
                                            //inversa=inversacomision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valsolrea)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;PEN";
                                            tipodecambio.innerHTML=valsolrea;
                                            tipodecomision.innerHTML=+valcomenviar+" PEN";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;PEN";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valsolrea;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Real a Sol';
                                            //trecibe.value=valtotalrecibe;
                                            tmoneda.value='Sol a Real';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case('usdbrl'):
                var valmontoinit=inputmontoenviar.value;
                var valmonto=valabajo;
                if(valmonto<0){
                    errorenvio.style.display='block';
                    errorenvio.innerHTML='Ingrese Monto mayor a 100';
                    tipodeimpuestos.innerHTML="0.00";
                    tipodecambio.innerHTML="0.00";
                    tipodecomision.innerHTML="0.00";
                    tipototalenviar.innerHTML="0.00";
                    tipototalrecibe.value="0.00";
                    numcomision.innerHTML="0.00";
                    tcambio.value=0;
                    tcomisi.value=0;
                    timpues.value=0;
                    ttotale.value=0;
                    tenviar.value=0;
                    trecibe.value=0;
                    tmoneda.value='Real a Dolar';
                    btnsiguiente.style.display='none';
                }else{
                    if(valmonto<200){
                        if(valmonto<200){
                            comision=co100a199usdabrl.value;
                            inversa=in100a199usdabrl.value;
                            //inversa=inversacomision100a199.value;
                            errorenvio.style.display='none';
                            valcomision=(parseFloat(comision)*100).toFixed(2);
                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                            tipodecambio.innerHTML=valusdareal;
                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                            inputmontoenviar.value=valtotalrecibe;
                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                            tcambio.value=valusdareal;
                            tcomisi.value=valcomenviar;
                            timpues.value=valimpuestos;
                            ttotale.value=valtotalenviar;
                            tenviar.value=resultadoinicial;//modificar
                            trecibe.value=valtotalrecibe;
                            tmoneda.value='Real a Dolar';
                            btnsiguiente.style.display='block';
                        }else{
                            if(valmonto<300){
                                comision=co200a299usdabrl.value;
                                inversa=in200a299usdabrl.value;
                                //inversa=inversacomision200a299.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                tipodecambio.innerHTML=valusdareal;
                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                inputmontoenviar.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valusdareal;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=resultadoinicial;//modificar
                                trecibe.value=valtotalrecibe;
                                tmoneda.value='Real a Dolar';
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<500){
                                    comision=co300a499usdabrl.value;
                                    inversa=in300a499usdabrl.value;
                                    //inversa=inversacomision300a399.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valusdareal;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valusdareal;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Real a Dolar';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<1000){
                                        comision=co500a999usdabrl.value;
                                        inversa=in500a999usdabrl.value;
                                        //inversa=inversacomision400a999.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valusdareal;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valusdareal;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Real a Dolar';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<3000){
                                            comision=co1000a2999usdabrl.value;
                                            inversa=in1000a2999usdabrl.value;
                                            //inversa=in1000a5000usdbrl;
                                            //comision=comision1000a5000.value;
                                            //inversa=inversacomision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valusdareal;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valusdareal;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Real a Dolar';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<=5000){
                                                comision=co3000a5000usdabrl.value;
                                                inversa=in3000a5000usdabrl.value;
                                                //inversa=in1000a5000usdbrl;
                                                //comision=comision1000a5000.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valusdareal;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valusdareal;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Real a Dolar';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                comision=co3000a5000usdabrl.value;
                                                inversa=in3000a5000usdabrl.value;
                                                //inversa=in1000a5000usdbrl;
                                                //comision=comision1000a5000.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valusdareal;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valusdareal;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Real a Dolar';
                                                btnsiguiente.style.display='block'; 
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }else{
                        if(valmonto<300){
                            if(valmonto<200){
                                comision=co100a199usdabrl.value;
                                inversa=in100a199usdabrl.value;
                                //inversa=inversacomision100a199.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                tipodecambio.innerHTML=valusdareal;
                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                inputmontoenviar.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valusdareal;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=resultadoinicial;//modificar
                                trecibe.value=valtotalrecibe;
                                tmoneda.value='Real a Dolar';
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<300){
                                    comision=co200a299usdabrl.value;
                                    inversa=in200a299usdabrl.value;
                                    //inversa=inversacomision200a299.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valusdareal;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valusdareal;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Real a Dolar';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<500){
                                        comision=co300a499usdabrl.value;
                                        inversa=in300a499usdabrl.value;
                                        //inversa=inversacomision300a399.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valusdareal;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valusdareal;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Real a Dolar';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<1000){
                                            comision=co500a999usdabrl.value;
                                            inversa=in500a999usdabrl.value;
                                            //inversa=inversacomision400a999.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valusdareal;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valusdareal;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Real a Dolar';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<3000){
                                                comision=co1000a2999usdabrl.value;
                                                inversa=in1000a2999usdabrl.value;
                                                //inversa=in1000a5000usdbrl;
                                                //comision=comision1000a5000.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valusdareal;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valusdareal;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Real a Dolar';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<=5000){
                                                    comision=co3000a5000usdabrl.value;
                                                    inversa=in3000a5000usdabrl.value;
                                                    //inversa=in1000a5000usdbrl;
                                                    //comision=comision1000a5000.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valusdareal;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valusdareal;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Real a Dolar';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    comision=co3000a5000usdabrl.value;
                                                    inversa=in3000a5000usdabrl.value;
                                                    //inversa=in1000a5000usdbrl;
                                                    //comision=comision1000a5000.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valusdareal;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valusdareal;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Real a Dolar';
                                                    btnsiguiente.style.display='block'; 
                                                } 
                                            }
                                        }
                                    }
                                }
                            }
                        }else{
                            if(valmonto<500){
                                if(valmonto<200){
                                    comision=co100a199usdabrl.value;
                                    inversa=in100a199usdabrl.value;
                                    //inversa=inversacomision100a199.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valusdareal;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valusdareal;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Real a Dolar';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<300){
                                        comision=co200a299usdabrl.value;
                                        inversa=in200a299usdabrl.value;
                                        //inversa=inversacomision200a299.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valusdareal;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valusdareal;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Real a Dolar';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<500){
                                            comision=co300a499usdabrl.value;
                                            inversa=in300a499usdabrl.value;
                                            //inversa=inversacomision300a399.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valusdareal;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valusdareal;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Real a Dolar';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<1000){
                                                comision=co500a999usdabrl.value;
                                                inversa=in500a999usdabrl.value;
                                                //inversa=inversacomision400a999.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valusdareal;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valusdareal;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Real a Dolar';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<3000){
                                                    comision=co1000a2999usdabrl.value;
                                                    inversa=in1000a2999usdabrl.value;
                                                    //inversa=in1000a5000usdbrl;
                                                    //comision=comision1000a5000.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valusdareal;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valusdareal;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Real a Dolar';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<=5000){
                                                        comision=co3000a5000usdabrl.value;
                                                        inversa=in3000a5000usdabrl.value;
                                                        //inversa=in1000a5000usdbrl;
                                                        //comision=comision1000a5000.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valusdareal;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valusdareal;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Real a Dolar';
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        comision=co3000a5000usdabrl.value;
                                                        inversa=in3000a5000usdabrl.value;
                                                        //inversa=in1000a5000usdbrl;
                                                        //comision=comision1000a5000.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valusdareal;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valusdareal;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Real a Dolar';
                                                        btnsiguiente.style.display='block'; 
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }else{
                                if(valmonto<1000){
                                    if(valmonto<200){
                                        comision=co100a199usdabrl.value;
                                        inversa=in100a199usdabrl.value;
                                        //inversa=inversacomision100a199.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valusdareal;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valusdareal;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Real a Dolar';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<300){
                                            comision=co200a299usdabrl.value;
                                            inversa=in200a299usdabrl.value;
                                            //inversa=inversacomision200a299.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valusdareal;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valusdareal;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Real a Dolar';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<500){
                                                comision=co300a499usdabrl.value;
                                                inversa=in300a499usdabrl.value;
                                                //inversa=inversacomision300a399.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valusdareal;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valusdareal;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Real a Dolar';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<1000){
                                                    comision=co500a999usdabrl.value;
                                                    inversa=in500a999usdabrl.value;
                                                    //inversa=inversacomision400a999.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valusdareal;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valusdareal;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Real a Dolar';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<3000){
                                                        comision=co1000a2999usdabrl.value;
                                                        inversa=in1000a2999usdabrl.value;
                                                        //inversa=in1000a5000usdbrl;
                                                        //comision=comision1000a5000.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valusdareal;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valusdareal;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Real a Dolar';
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<=5000){
                                                            comision=co3000a5000usdabrl.value;
                                                            inversa=in3000a5000usdabrl.value;
                                                            //inversa=in1000a5000usdbrl;
                                                            //comision=comision1000a5000.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valusdareal;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valusdareal;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Real a Dolar';
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            comision=co3000a5000usdabrl.value;
                                                            inversa=in3000a5000usdabrl.value;
                                                            //inversa=in1000a5000usdbrl;
                                                            //comision=comision1000a5000.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valusdareal;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valusdareal;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Real a Dolar';
                                                            btnsiguiente.style.display='block'; 
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }else{
                                    if(valmonto<3000){
                                        if(valmonto<200){
                                            comision=co100a199usdabrl.value;
                                            inversa=in100a199usdabrl.value;
                                            //inversa=inversacomision100a199.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valusdareal;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valusdareal;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Real a Dolar';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<300){
                                                comision=co200a299usdabrl.value;
                                                inversa=in200a299usdabrl.value;
                                                //inversa=inversacomision200a299.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valusdareal;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valusdareal;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Real a Dolar';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<500){
                                                    comision=co300a499usdabrl.value;
                                                    inversa=in300a499usdabrl.value;
                                                    //inversa=inversacomision300a399.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valusdareal;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valusdareal;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Real a Dolar';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<1000){
                                                        comision=co500a999usdabrl.value;
                                                        inversa=in500a999usdabrl.value;
                                                        //inversa=inversacomision400a999.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valusdareal;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valusdareal;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Real a Dolar';
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<3000){
                                                            comision=co1000a2999usdabrl.value;
                                                            inversa=in1000a2999usdabrl.value;
                                                            //inversa=in1000a5000usdbrl;
                                                            //comision=comision1000a5000.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valusdareal;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valusdareal;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Real a Dolar';
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            if(valmonto<=5000){
                                                                comision=co3000a5000usdabrl.value;
                                                                inversa=in3000a5000usdabrl.value;
                                                                //inversa=in1000a5000usdbrl;
                                                                //comision=comision1000a5000.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valusdareal;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valusdareal;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                trecibe.value=valtotalrecibe;
                                                                tmoneda.value='Real a Dolar';
                                                                btnsiguiente.style.display='block';
                                                            }else{
                                                                comision=co3000a5000usdabrl.value;
                                                                inversa=in3000a5000usdabrl.value;
                                                                //inversa=in1000a5000usdbrl;
                                                                //comision=comision1000a5000.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valusdareal;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valusdareal;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                trecibe.value=valtotalrecibe;
                                                                tmoneda.value='Real a Dolar';
                                                                btnsiguiente.style.display='block'; 
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }else{
                                        if(valmonto<=5000){
                                            if(valmonto<200){
                                                comision=co100a199usdabrl.value;
                                                inversa=in100a199usdabrl.value;
                                                //inversa=inversacomision100a199.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valusdareal;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valusdareal;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Real a Dolar';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<300){
                                                    comision=co200a299usdabrl.value;
                                                    inversa=in200a299usdabrl.value;
                                                    //inversa=inversacomision200a299.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valusdareal;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valusdareal;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Real a Dolar';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<500){
                                                        comision=co300a499usdabrl.value;
                                                        inversa=in300a499usdabrl.value;
                                                        //inversa=inversacomision300a399.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valusdareal;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valusdareal;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Real a Dolar';
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<1000){
                                                            comision=co500a999usdabrl.value;
                                                            inversa=in500a999usdabrl.value;
                                                            //inversa=inversacomision400a999.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valusdareal;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valusdareal;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Real a Dolar';
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            if(valmonto<3000){
                                                                comision=co1000a2999usdabrl.value;
                                                                inversa=in1000a2999usdabrl.value;
                                                                //inversa=in1000a5000usdbrl;
                                                                //comision=comision1000a5000.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valusdareal;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valusdareal;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                trecibe.value=valtotalrecibe;
                                                                tmoneda.value='Real a Dolar';
                                                                btnsiguiente.style.display='block';
                                                            }else{
                                                                if(valmonto<=5000){
                                                                    comision=co3000a5000usdabrl.value;
                                                                    inversa=in3000a5000usdabrl.value;
                                                                    //inversa=in1000a5000usdbrl;
                                                                    //comision=comision1000a5000.value;
                                                                    //inversa=inversacomision1000a5000.value;
                                                                    errorenvio.style.display='none';
                                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                    tipodecambio.innerHTML=valusdareal;
                                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                    inputmontoenviar.value=valtotalrecibe;
                                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                    tcambio.value=valusdareal;
                                                                    tcomisi.value=valcomenviar;
                                                                    timpues.value=valimpuestos;
                                                                    ttotale.value=valtotalenviar;
                                                                    tenviar.value=resultadoinicial;//modificar
                                                                    trecibe.value=valtotalrecibe;
                                                                    tmoneda.value='Real a Dolar';
                                                                    btnsiguiente.style.display='block';
                                                                }else{
                                                                    comision=co3000a5000usdabrl.value;
                                                                    inversa=in3000a5000usdabrl.value;
                                                                    //inversa=in1000a5000usdbrl;
                                                                    //comision=comision1000a5000.value;
                                                                    //inversa=inversacomision1000a5000.value;
                                                                    errorenvio.style.display='none';
                                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                    tipodecambio.innerHTML=valusdareal;
                                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                    inputmontoenviar.value=valtotalrecibe;
                                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                    tcambio.value=valusdareal;
                                                                    tcomisi.value=valcomenviar;
                                                                    timpues.value=valimpuestos;
                                                                    ttotale.value=valtotalenviar;
                                                                    tenviar.value=resultadoinicial;//modificar
                                                                    trecibe.value=valtotalrecibe;
                                                                    tmoneda.value='Real a Dolar';
                                                                    btnsiguiente.style.display='block'; 
                                                                } 
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }else{
                                            comision=co3000a5000usdabrl.value;
                                            inversa=in3000a5000usdabrl.value;
                                            //inversa=in1000a5000usdbrl;
                                            //comision=comision1000a5000.value;
                                            //inversa=inversacomision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valusdareal)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valusdareal;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valusdareal;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Real a Dolar';
                                            btnsiguiente.style.display='block'; 
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case('brlpen'):
                var valmontoinit=inputmontoenviar.value;
                var valmonto=valabajo;
                if(valmonto<0){
                    errorenvio.style.display='block';
                    errorenvio.innerHTML='Ingrese Monto mayor a 100';
                    tipodeimpuestos.innerHTML="0.00";
                    tipodecambio.innerHTML="0.00";
                    tipodecomision.innerHTML="0.00";
                    tipototalenviar.innerHTML="0.00";
                    tipototalrecibe.value="0.00";
                    numcomision.innerHTML="0.00";
                    tcambio.value=0;
                    tcomisi.value=0;
                    timpues.value=0;
                    ttotale.value=0;
                    tenviar.value=0;
                    trecibe.value=0;
                    tmoneda.value='Sol a Real';
                    btnsiguiente.style.display='none';
                }else{
                    if(valmonto<200){
                        //inicia
                        if(valmonto<200){
                            comision=co100a199brlapen.value;
                            inversa=in100a199brlapen.value;
                            //inversa=inversacomision100a199.value;
                            errorenvio.style.display='none';
                            valcomision=(parseFloat(comision)*100).toFixed(2);
                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                            tipodecambio.innerHTML=valrealapen;
                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                            inputmontoenviar.value=valtotalrecibe;
                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                            tcambio.value=valrealapen;
                            tcomisi.value=valcomenviar;
                            timpues.value=valimpuestos;
                            ttotale.value=valtotalenviar;
                            tenviar.value=resultadoinicial;//modificar
                            //tmoneda.value='Sol a Real';
                            tmoneda.value='Real a Sol';
                            trecibe.value=tipototalrecibe.value;
                            btnsiguiente.style.display='block';
                        }else{
                            if(valmonto<300){
                                comision=co200a299brlapen.value;
                                inversa=in200a299brlapen.value;
                                //inversa=inversacomision200a299.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                tipodecambio.innerHTML=valrealapen;
                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                inputmontoenviar.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valrealapen;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=resultadoinicial;//modificar
                                //tmoneda.value='Sol a Real';
                                tmoneda.value='Real a Sol';
                                trecibe.value=tipototalrecibe.value;
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<500){
                                    comision=co300a499brlapen.value;
                                    inversa=in300a499brlapen.value;
                                    //inversa=inversacomision300a399.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valrealapen;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valrealapen;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    //tmoneda.value='Sol a Real';
                                    tmoneda.value='Real a Sol';
                                    trecibe.value=tipototalrecibe.value;
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<1000){
                                        comision=co500a999brlapen.value;
                                        inversa=in500a999brlapen.value;
                                        //inversa=inversacomision400a999.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealapen;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealapen;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        //tmoneda.value='Sol a Real';
                                        tmoneda.value='Real a Sol';
                                        trecibe.value=tipototalrecibe.value;
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<3000){
                                            comision=co1000a2999brlapen.value;
                                            inversa=in1000a2999brlapen.value;
                                            //inversa=inversacomision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealapen;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealapen;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Sol a Real';
                                            tmoneda.value='Real a Sol';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<=5000){
                                                comision=co3000a5000brlapen.value;
                                                inversa=in3000a5000brlapen.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealapen;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealapen;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Sol a Real';
                                                tmoneda.value='Real a Sol';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                comision=co3000a5000brlapen.value;
                                                inversa=in3000a5000brlapen.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealapen;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealapen;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Sol a Real';
                                                tmoneda.value='Real a Sol';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        //termina
                    }else{
                        if(valmonto<300){
                            if(valmonto<200){
                                comision=co100a199brlapen.value;
                                inversa=in100a199brlapen.value;
                                //inversa=inversacomision100a199.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                tipodecambio.innerHTML=valrealapen;
                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                inputmontoenviar.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valrealapen;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=resultadoinicial;//modificar
                                //tmoneda.value='Sol a Real';
                                tmoneda.value='Real a Sol';
                                trecibe.value=tipototalrecibe.value;
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<300){
                                    comision=co200a299brlapen.value;
                                    inversa=in200a299brlapen.value;
                                    //inversa=inversacomision200a299.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valrealapen;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valrealapen;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    //tmoneda.value='Sol a Real';
                                    tmoneda.value='Real a Sol';
                                    trecibe.value=tipototalrecibe.value;
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<500){
                                        comision=co300a499brlapen.value;
                                        inversa=in300a499brlapen.value;
                                        //inversa=inversacomision300a399.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealapen;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealapen;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        //tmoneda.value='Sol a Real';
                                        tmoneda.value='Real a Sol';
                                        trecibe.value=tipototalrecibe.value;
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<1000){
                                            comision=co500a999brlapen.value;
                                            inversa=in500a999brlapen.value;
                                            //inversa=inversacomision400a999.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealapen;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealapen;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Sol a Real';
                                            tmoneda.value='Real a Sol';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<3000){
                                                comision=co1000a2999brlapen.value;
                                                inversa=in1000a2999brlapen.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealapen;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealapen;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Sol a Real';
                                                tmoneda.value='Real a Sol';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<=5000){
                                                    comision=co3000a5000brlapen.value;
                                                    inversa=in3000a5000brlapen.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealapen;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealapen;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Sol a Real';
                                                    tmoneda.value='Real a Sol';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    comision=co3000a5000brlapen.value;
                                                    inversa=in3000a5000brlapen.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealapen;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealapen;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Sol a Real';
                                                    tmoneda.value='Real a Sol';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }else{
                            if(valmonto<500){
                                if(valmonto<200){
                                    comision=co100a199brlapen.value;
                                    inversa=in100a199brlapen.value;
                                    //inversa=inversacomision100a199.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valrealapen;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valrealapen;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    //tmoneda.value='Sol a Real';
                                    tmoneda.value='Real a Sol';
                                    trecibe.value=tipototalrecibe.value;
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<300){
                                        comision=co200a299brlapen.value;
                                        inversa=in200a299brlapen.value;
                                        //inversa=inversacomision200a299.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealapen;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealapen;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        //tmoneda.value='Sol a Real';
                                        tmoneda.value='Real a Sol';
                                        trecibe.value=tipototalrecibe.value;
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<500){
                                            comision=co300a499brlapen.value;
                                            inversa=in300a499brlapen.value;
                                            //inversa=inversacomision300a399.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealapen;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealapen;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Sol a Real';
                                            tmoneda.value='Real a Sol';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<1000){
                                                comision=co500a999brlapen.value;
                                                inversa=in500a999brlapen.value;
                                                //inversa=inversacomision400a999.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealapen;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealapen;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Sol a Real';
                                                tmoneda.value='Real a Sol';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<3000){
                                                    comision=co1000a2999brlapen.value;
                                                    inversa=in1000a2999brlapen.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealapen;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealapen;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Sol a Real';
                                                    tmoneda.value='Real a Sol';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<=5000){
                                                        comision=co3000a5000brlapen.value;
                                                        inversa=in3000a5000brlapen.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealapen;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealapen;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        //tmoneda.value='Sol a Real';
                                                        tmoneda.value='Real a Sol';
                                                        trecibe.value=tipototalrecibe.value;
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        comision=co3000a5000brlapen.value;
                                                        inversa=in3000a5000brlapen.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealapen;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealapen;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        //tmoneda.value='Sol a Real';
                                                        tmoneda.value='Real a Sol';
                                                        trecibe.value=tipototalrecibe.value;
                                                        btnsiguiente.style.display='block';
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }else{
                                if(valmonto<1000){
                                    if(valmonto<200){
                                        comision=co100a199brlapen.value;
                                        inversa=in100a199brlapen.value;
                                        //inversa=inversacomision100a199.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealapen;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealapen;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        //tmoneda.value='Sol a Real';
                                        tmoneda.value='Real a Sol';
                                        trecibe.value=tipototalrecibe.value;
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<300){
                                            comision=co200a299brlapen.value;
                                            inversa=in200a299brlapen.value;
                                            //inversa=inversacomision200a299.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealapen;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealapen;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Sol a Real';
                                            tmoneda.value='Real a Sol';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<500){
                                                comision=co300a499brlapen.value;
                                                inversa=in300a499brlapen.value;
                                                //inversa=inversacomision300a399.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealapen;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealapen;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Sol a Real';
                                                tmoneda.value='Real a Sol';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<1000){
                                                    comision=co500a999brlapen.value;
                                                    inversa=in500a999brlapen.value;
                                                    //inversa=inversacomision400a999.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealapen;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealapen;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Sol a Real';
                                                    tmoneda.value='Real a Sol';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<3000){
                                                        comision=co1000a2999brlapen.value;
                                                        inversa=in1000a2999brlapen.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealapen;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealapen;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        //tmoneda.value='Sol a Real';
                                                        tmoneda.value='Real a Sol';
                                                        trecibe.value=tipototalrecibe.value;
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<=5000){
                                                            comision=co3000a5000brlapen.value;
                                                            inversa=in3000a5000brlapen.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valrealapen;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valrealapen;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            //tmoneda.value='Sol a Real';
                                                            tmoneda.value='Real a Sol';
                                                            trecibe.value=tipototalrecibe.value;
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            comision=co3000a5000brlapen.value;
                                                            inversa=in3000a5000brlapen.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valrealapen;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valrealapen;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            //tmoneda.value='Sol a Real';
                                                            tmoneda.value='Real a Sol';
                                                            trecibe.value=tipototalrecibe.value;
                                                            btnsiguiente.style.display='block';
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }else{
                                    if(valmonto<3000){
                                        if(valmonto<200){
                                            comision=co100a199brlapen.value;
                                            inversa=in100a199brlapen.value;
                                            //inversa=inversacomision100a199.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealapen;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealapen;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Sol a Real';
                                            tmoneda.value='Real a Sol';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<300){
                                                comision=co200a299brlapen.value;
                                                inversa=in200a299brlapen.value;
                                                //inversa=inversacomision200a299.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealapen;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealapen;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Sol a Real';
                                                tmoneda.value='Real a Sol';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<500){
                                                    comision=co300a499brlapen.value;
                                                    inversa=in300a499brlapen.value;
                                                    //inversa=inversacomision300a399.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealapen;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealapen;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Sol a Real';
                                                    tmoneda.value='Real a Sol';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<1000){
                                                        comision=co500a999brlapen.value;
                                                        inversa=in500a999brlapen.value;
                                                        //inversa=inversacomision400a999.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealapen;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealapen;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        //tmoneda.value='Sol a Real';
                                                        tmoneda.value='Real a Sol';
                                                        trecibe.value=tipototalrecibe.value;
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<3000){
                                                            comision=co1000a2999brlapen.value;
                                                            inversa=in1000a2999brlapen.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valrealapen;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valrealapen;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            //tmoneda.value='Sol a Real';
                                                            tmoneda.value='Real a Sol';
                                                            trecibe.value=tipototalrecibe.value;
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            if(valmonto<=5000){
                                                                comision=co3000a5000brlapen.value;
                                                                inversa=in3000a5000brlapen.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valrealapen;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valrealapen;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                //tmoneda.value='Sol a Real';
                                                                tmoneda.value='Real a Sol';
                                                                trecibe.value=tipototalrecibe.value;
                                                                btnsiguiente.style.display='block';
                                                            }else{
                                                                comision=co3000a5000brlapen.value;
                                                                inversa=in3000a5000brlapen.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valrealapen;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valrealapen;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                //tmoneda.value='Sol a Real';
                                                                tmoneda.value='Real a Sol';
                                                                trecibe.value=tipototalrecibe.value;
                                                                btnsiguiente.style.display='block';
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }else{
                                        if(valmonto<=5000){
                                            if(valmonto<200){
                                                comision=co100a199brlapen.value;
                                                inversa=in100a199brlapen.value;
                                                //inversa=inversacomision100a199.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealapen;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealapen;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                //tmoneda.value='Sol a Real';
                                                tmoneda.value='Real a Sol';
                                                trecibe.value=tipototalrecibe.value;
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<300){
                                                    comision=co200a299brlapen.value;
                                                    inversa=in200a299brlapen.value;
                                                    //inversa=inversacomision200a299.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealapen;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealapen;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    //tmoneda.value='Sol a Real';
                                                    tmoneda.value='Real a Sol';
                                                    trecibe.value=tipototalrecibe.value;
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<500){
                                                        comision=co300a499brlapen.value;
                                                        inversa=in300a499brlapen.value;
                                                        //inversa=inversacomision300a399.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealapen;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealapen;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        //tmoneda.value='Sol a Real';
                                                        tmoneda.value='Real a Sol';
                                                        trecibe.value=tipototalrecibe.value;
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<1000){
                                                            comision=co500a999brlapen.value;
                                                            inversa=in500a999brlapen.value;
                                                            //inversa=inversacomision400a999.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valrealapen;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valrealapen;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            //tmoneda.value='Sol a Real';
                                                            tmoneda.value='Real a Sol';
                                                            trecibe.value=tipototalrecibe.value;
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            if(valmonto<=5000){
                                                                comision=co3000a5000brlapen.value;
                                                                inversa=in3000a5000brlapen.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valrealapen;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valrealapen;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                //tmoneda.value='Sol a Real';
                                                                tmoneda.value='Real a Sol';
                                                                trecibe.value=tipototalrecibe.value;
                                                                btnsiguiente.style.display='block';
                                                            }else{
                                                                comision=co3000a5000brlapen.value;
                                                                inversa=in3000a5000brlapen.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valrealapen;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valrealapen;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                //tmoneda.value='Sol a Real';
                                                                tmoneda.value='Real a Sol';
                                                                trecibe.value=tipototalrecibe.value;
                                                                btnsiguiente.style.display='block';
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }else{
                                            comision=co3000a5000brlapen.value;
                                            inversa=in3000a5000brlapen.value;
                                            //inversa=inversacomision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealapen)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealapen;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificarss
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealapen;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            //tmoneda.value='Sol a Real';
                                            tmoneda.value='Real a Sol';
                                            trecibe.value=tipototalrecibe.value;
                                            btnsiguiente.style.display='block';
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case('brlusd'):
                var valmontoinit=inputmontoenviar.value;
                var valmonto=valabajo;
                if(valmonto<0){
                    errorenvio.style.display='block';
                    errorenvio.innerHTML='Ingrese Monto mayor a 100';
                    tipodeimpuestos.innerHTML="0.00";
                    tipodecambio.innerHTML="0.00";
                    tipodecomision.innerHTML="0.00";
                    tipototalenviar.innerHTML="0.00";
                    tipototalrecibe.value="0.00";
                    numcomision.innerHTML="0.00";
                    tcambio.value=0;
                    tcomisi.value=0;
                    timpues.value=0;
                    ttotale.value=0;
                    tenviar.value=0;
                    trecibe.value=0;
                    tmoneda.value='Dolar a Real';
                    btnsiguiente.style.display='none';
                }else{
                    if(valmonto<200){
                        //inicia
                        if(valmonto<200){
                            comision=co100a199brlausd.value;
                            inversa=in100a199brlausd.value;
                            //inversa=inversacomision100a199.value;
                            errorenvio.style.display='none';
                            valcomision=(parseFloat(comision)*100).toFixed(2);
                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                            tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                            tipodecambio.innerHTML=valrealausd;
                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                            inputmontoenviar.value=valtotalrecibe;
                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                            tcambio.value=valrealausd;
                            tcomisi.value=valcomenviar;
                            timpues.value=valimpuestos;
                            ttotale.value=valtotalenviar;
                            tenviar.value=resultadoinicial;//modificar
                            trecibe.value=valtotalrecibe;
                            tmoneda.value='Dolar a Real';
                            btnsiguiente.style.display='block';
                        }else{
                            if(valmonto<300){
                                comision=co200a299brlausd.value;
                                inversa=in200a299brlausd.value;
                                //inversa=inversacomision200a299.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                tipodecambio.innerHTML=valrealausd;
                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                inputmontoenviar.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valrealausd;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=resultadoinicial;//modificar
                                trecibe.value=valtotalrecibe;
                                tmoneda.value='Dolar a Real';
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<500){
                                    comision=co300a499brlausd.value;
                                    inversa=in300a499brlausd.value;
                                    //inversa=inversacomision300a399.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valrealausd;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valrealausd;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Dolar a Real';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<1000){
                                        comision=co500a999brlausd.value;
                                        inversa=in500a999brlausd.value;
                                        //inversa=inversacomision400a999.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealausd;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealausd;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Dolar a Real';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<3000){
                                            comision=co1000a2999brlausd.value;
                                            inversa=in1000a2999brlausd.value;
                                            //inversa=in1000a5000brlusd;
                                            //comision=comision1000a5000.value;
                                            //inversa=inversacomision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealausd;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealausd;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Dolar a Real';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<=5000){
                                                comision=co3000a5000brlausd.value;
                                                inversa=in3000a5000brlausd.value;
                                                //inversa=in1000a5000brlusd;
                                                //comision=comision1000a5000.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealausd;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealausd;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Dolar a Real';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                comision=co3000a5000brlausd.value;
                                                inversa=in3000a5000brlausd.value;
                                                //inversa=in1000a5000brlusd;
                                                //comision=comision1000a5000.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealausd;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealausd;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Dolar a Real';
                                                btnsiguiente.style.display='block';
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        //termina
                    }else{
                        if(valmonto<300){
                            //inicia
                            if(valmonto<200){
                                comision=co100a199brlausd.value;
                                inversa=in100a199brlausd.value;
                                //inversa=inversacomision100a199.value;
                                errorenvio.style.display='none';
                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                tipodecambio.innerHTML=valrealausd;
                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                inputmontoenviar.value=valtotalrecibe;
                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                tcambio.value=valrealausd;
                                tcomisi.value=valcomenviar;
                                timpues.value=valimpuestos;
                                ttotale.value=valtotalenviar;
                                tenviar.value=resultadoinicial;//modificar
                                trecibe.value=valtotalrecibe;
                                tmoneda.value='Dolar a Real';
                                btnsiguiente.style.display='block';
                            }else{
                                if(valmonto<300){
                                    comision=co200a299brlausd.value;
                                    inversa=in200a299brlausd.value;
                                    //inversa=inversacomision200a299.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valrealausd;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valrealausd;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Dolar a Real';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<500){
                                        comision=co300a499brlausd.value;
                                        inversa=in300a499brlausd.value;
                                        //inversa=inversacomision300a399.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealausd;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealausd;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Dolar a Real';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<1000){
                                            comision=co500a999brlausd.value;
                                            inversa=in500a999brlausd.value;
                                            //inversa=inversacomision400a999.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealausd;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealausd;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Dolar a Real';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<3000){
                                                comision=co1000a2999brlausd.value;
                                                inversa=in1000a2999brlausd.value;
                                                //inversa=in1000a5000brlusd;
                                                //comision=comision1000a5000.value;
                                                //inversa=inversacomision1000a5000.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealausd;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealausd;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Dolar a Real';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<=5000){
                                                    comision=co3000a5000brlausd.value;
                                                    inversa=in3000a5000brlausd.value;
                                                    //inversa=in1000a5000brlusd;
                                                    //comision=comision1000a5000.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealausd;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealausd;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Dolar a Real';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    comision=co3000a5000brlausd.value;
                                                    inversa=in3000a5000brlausd.value;
                                                    //inversa=in1000a5000brlusd;
                                                    //comision=comision1000a5000.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealausd;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealausd;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Dolar a Real';
                                                    btnsiguiente.style.display='block';
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            //termina
                        }else{
                            if(valmonto<500){
                                //inicia
                                if(valmonto<200){
                                    comision=co100a199brlausd.value;
                                    inversa=in100a199brlausd.value;
                                    //inversa=inversacomision100a199.value;
                                    errorenvio.style.display='none';
                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                    tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                    tipodecambio.innerHTML=valrealausd;
                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                    inputmontoenviar.value=valtotalrecibe;
                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                    tcambio.value=valrealausd;
                                    tcomisi.value=valcomenviar;
                                    timpues.value=valimpuestos;
                                    ttotale.value=valtotalenviar;
                                    tenviar.value=resultadoinicial;//modificar
                                    trecibe.value=valtotalrecibe;
                                    tmoneda.value='Dolar a Real';
                                    btnsiguiente.style.display='block';
                                }else{
                                    if(valmonto<300){
                                        comision=co200a299brlausd.value;
                                        inversa=in200a299brlausd.value;
                                        //inversa=inversacomision200a299.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealausd;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealausd;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Dolar a Real';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<500){
                                            comision=co300a499brlausd.value;
                                            inversa=in300a499brlausd.value;
                                            //inversa=inversacomision300a399.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealausd;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealausd;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Dolar a Real';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<1000){
                                                comision=co500a999brlausd.value;
                                                inversa=in500a999brlausd.value;
                                                //inversa=inversacomision400a999.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealausd;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealausd;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Dolar a Real';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<3000){
                                                    comision=co1000a2999brlausd.value;
                                                    inversa=in1000a2999brlausd.value;
                                                    //inversa=in1000a5000brlusd;
                                                    //comision=comision1000a5000.value;
                                                    //inversa=inversacomision1000a5000.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealausd;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealausd;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Dolar a Real';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<=5000){
                                                        comision=co3000a5000brlausd.value;
                                                        inversa=in3000a5000brlausd.value;
                                                        //inversa=in1000a5000brlusd;
                                                        //comision=comision1000a5000.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealausd;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealausd;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Dolar a Real';
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        comision=co3000a5000brlausd.value;
                                                        inversa=in3000a5000brlausd.value;
                                                        //inversa=in1000a5000brlusd;
                                                        //comision=comision1000a5000.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealausd;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealausd;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Dolar a Real';
                                                        btnsiguiente.style.display='block';
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                //termina
                            }else{
                                if(valmonto<1000){
                                    //inicia
                                    if(valmonto<200){
                                        comision=co100a199brlausd.value;
                                        inversa=in100a199brlausd.value;
                                        //inversa=inversacomision100a199.value;
                                        errorenvio.style.display='none';
                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                        tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                        tipodecambio.innerHTML=valrealausd;
                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                        inputmontoenviar.value=valtotalrecibe;
                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                        tcambio.value=valrealausd;
                                        tcomisi.value=valcomenviar;
                                        timpues.value=valimpuestos;
                                        ttotale.value=valtotalenviar;
                                        tenviar.value=resultadoinicial;//modificar
                                        trecibe.value=valtotalrecibe;
                                        tmoneda.value='Dolar a Real';
                                        btnsiguiente.style.display='block';
                                    }else{
                                        if(valmonto<300){
                                            comision=co200a299brlausd.value;
                                            inversa=in200a299brlausd.value;
                                            //inversa=inversacomision200a299.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealausd;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealausd;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Dolar a Real';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<500){
                                                comision=co300a499brlausd.value;
                                                inversa=in300a499brlausd.value;
                                                //inversa=inversacomision300a399.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealausd;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealausd;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Dolar a Real';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<1000){
                                                    comision=co500a999brlausd.value;
                                                    inversa=in500a999brlausd.value;
                                                    //inversa=inversacomision400a999.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealausd;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealausd;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Dolar a Real';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<3000){
                                                        comision=co1000a2999brlausd.value;
                                                        inversa=in1000a2999brlausd.value;
                                                        //inversa=in1000a5000brlusd;
                                                        //comision=comision1000a5000.value;
                                                        //inversa=inversacomision1000a5000.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealausd;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealausd;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Dolar a Real';
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<=5000){
                                                            comision=co3000a5000brlausd.value;
                                                            inversa=in3000a5000brlausd.value;
                                                            //inversa=in1000a5000brlusd;
                                                            //comision=comision1000a5000.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valrealausd;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valrealausd;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Dolar a Real';
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            comision=co3000a5000brlausd.value;
                                                            inversa=in3000a5000brlausd.value;
                                                            //inversa=in1000a5000brlusd;
                                                            //comision=comision1000a5000.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valrealausd;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valrealausd;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Dolar a Real';
                                                            btnsiguiente.style.display='block';
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    //termina
                                }else{
                                    if(valmonto<3000){
                                        //inicia
                                        if(valmonto<200){
                                            comision=co100a199brlausd.value;
                                            inversa=in100a199brlausd.value;
                                            //inversa=inversacomision100a199.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealausd;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealausd;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Dolar a Real';
                                            btnsiguiente.style.display='block';
                                        }else{
                                            if(valmonto<300){
                                                comision=co200a299brlausd.value;
                                                inversa=in200a299brlausd.value;
                                                //inversa=inversacomision200a299.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealausd;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealausd;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Dolar a Real';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<500){
                                                    comision=co300a499brlausd.value;
                                                    inversa=in300a499brlausd.value;
                                                    //inversa=inversacomision300a399.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealausd;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealausd;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Dolar a Real';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<1000){
                                                        comision=co500a999brlausd.value;
                                                        inversa=in500a999brlausd.value;
                                                        //inversa=inversacomision400a999.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealausd;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealausd;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Dolar a Real';
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<3000){
                                                            comision=co1000a2999brlausd.value;
                                                            inversa=in1000a2999brlausd.value;
                                                            //inversa=in1000a5000brlusd;
                                                            //comision=comision1000a5000.value;
                                                            //inversa=inversacomision1000a5000.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valrealausd;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valrealausd;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Dolar a Real';
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            if(valmonto<=5000){
                                                                comision=co3000a5000brlausd.value;
                                                                inversa=in3000a5000brlausd.value;
                                                                //inversa=in1000a5000brlusd;
                                                                //comision=comision1000a5000.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valrealausd;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valrealausd;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                trecibe.value=valtotalrecibe;
                                                                tmoneda.value='Dolar a Real';
                                                                btnsiguiente.style.display='block';
                                                            }else{
                                                                comision=co3000a5000brlausd.value;
                                                                inversa=in3000a5000brlausd.value;
                                                                //inversa=in1000a5000brlusd;
                                                                //comision=comision1000a5000.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valrealausd;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valrealausd;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                trecibe.value=valtotalrecibe;
                                                                tmoneda.value='Dolar a Real';
                                                                btnsiguiente.style.display='block';
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        //termina
                                    }else{
                                        if(valmonto<=5000){
                                        //inicia
                                            if(valmonto<200){
                                                comision=co100a199brlausd.value;
                                                inversa=in100a199brlausd.value;
                                                //inversa=inversacomision100a199.value;
                                                errorenvio.style.display='none';
                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                tipodecambio.innerHTML=valrealausd;
                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                inputmontoenviar.value=valtotalrecibe;
                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                tcambio.value=valrealausd;
                                                tcomisi.value=valcomenviar;
                                                timpues.value=valimpuestos;
                                                ttotale.value=valtotalenviar;
                                                tenviar.value=resultadoinicial;//modificar
                                                trecibe.value=valtotalrecibe;
                                                tmoneda.value='Dolar a Real';
                                                btnsiguiente.style.display='block';
                                            }else{
                                                if(valmonto<300){
                                                    comision=co200a299brlausd.value;
                                                    inversa=in200a299brlausd.value;
                                                    //inversa=inversacomision200a299.value;
                                                    errorenvio.style.display='none';
                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                    tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                    tipodecambio.innerHTML=valrealausd;
                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                    inputmontoenviar.value=valtotalrecibe;
                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                    tcambio.value=valrealausd;
                                                    tcomisi.value=valcomenviar;
                                                    timpues.value=valimpuestos;
                                                    ttotale.value=valtotalenviar;
                                                    tenviar.value=resultadoinicial;//modificar
                                                    trecibe.value=valtotalrecibe;
                                                    tmoneda.value='Dolar a Real';
                                                    btnsiguiente.style.display='block';
                                                }else{
                                                    if(valmonto<500){
                                                        comision=co300a499brlausd.value;
                                                        inversa=in300a499brlausd.value;
                                                        //inversa=inversacomision300a399.value;
                                                        errorenvio.style.display='none';
                                                        valcomision=(parseFloat(comision)*100).toFixed(2);
                                                        resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                        valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                        valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                        valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                        valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                        tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                        tipodecambio.innerHTML=valrealausd;
                                                        tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                        tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                        valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                        inputmontoenviar.value=valtotalrecibe;
                                                        numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                        tcambio.value=valrealausd;
                                                        tcomisi.value=valcomenviar;
                                                        timpues.value=valimpuestos;
                                                        ttotale.value=valtotalenviar;
                                                        tenviar.value=resultadoinicial;//modificar
                                                        trecibe.value=valtotalrecibe;
                                                        tmoneda.value='Dolar a Real';
                                                        btnsiguiente.style.display='block';
                                                    }else{
                                                        if(valmonto<1000){
                                                            comision=co500a999brlausd.value;
                                                            inversa=in500a999brlausd.value;
                                                            //inversa=inversacomision400a999.value;
                                                            errorenvio.style.display='none';
                                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                            tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                            tipodecambio.innerHTML=valrealausd;
                                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                            inputmontoenviar.value=valtotalrecibe;
                                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                            tcambio.value=valrealausd;
                                                            tcomisi.value=valcomenviar;
                                                            timpues.value=valimpuestos;
                                                            ttotale.value=valtotalenviar;
                                                            tenviar.value=resultadoinicial;//modificar
                                                            trecibe.value=valtotalrecibe;
                                                            tmoneda.value='Dolar a Real';
                                                            btnsiguiente.style.display='block';
                                                        }else{
                                                            if(valmonto<3000){
                                                                comision=co1000a2999brlausd.value;
                                                                inversa=in1000a2999brlausd.value;
                                                                //inversa=in1000a5000brlusd;
                                                                //comision=comision1000a5000.value;
                                                                //inversa=inversacomision1000a5000.value;
                                                                errorenvio.style.display='none';
                                                                valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                                valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                                tipodecambio.innerHTML=valrealausd;
                                                                tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                inputmontoenviar.value=valtotalrecibe;
                                                                numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                tcambio.value=valrealausd;
                                                                tcomisi.value=valcomenviar;
                                                                timpues.value=valimpuestos;
                                                                ttotale.value=valtotalenviar;
                                                                tenviar.value=resultadoinicial;//modificar
                                                                trecibe.value=valtotalrecibe;
                                                                tmoneda.value='Dolar a Real';
                                                                btnsiguiente.style.display='block';
                                                            }else{
                                                                if(valmonto<=5000){
                                                                    comision=co3000a5000brlausd.value;
                                                                    inversa=in3000a5000brlausd.value;
                                                                    //inversa=in1000a5000brlusd;
                                                                    //comision=comision1000a5000.value;
                                                                    //inversa=inversacomision1000a5000.value;
                                                                    errorenvio.style.display='none';
                                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                    tipodeimpuestos.innerHTML=parseFloat(valimpuestos).toFixed(2)+"&nbsp;BRL";
                                                                    tipodecambio.innerHTML=valrealausd;
                                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                    inputmontoenviar.value=valtotalrecibe;
                                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                    tcambio.value=valrealausd;
                                                                    tcomisi.value=valcomenviar;
                                                                    timpues.value=valimpuestos;
                                                                    ttotale.value=valtotalenviar;
                                                                    tenviar.value=resultadoinicial;//modificar
                                                                    trecibe.value=valtotalrecibe;
                                                                    tmoneda.value='Dolar a Real';
                                                                    btnsiguiente.style.display='block';
                                                                }else{
                                                                    comision=co3000a5000brlausd.value;
                                                                    inversa=in3000a5000brlausd.value;
                                                                    //inversa=in1000a5000brlusd;
                                                                    //comision=comision1000a5000.value;
                                                                    //inversa=inversacomision1000a5000.value;
                                                                    errorenvio.style.display='none';
                                                                    valcomision=(parseFloat(comision)*100).toFixed(2);
                                                                    resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                                                    valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                                                    valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                                                    valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                                                    valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                                                    tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                                                    tipodecambio.innerHTML=valrealausd;
                                                                    tipodecomision.innerHTML=+valcomenviar+" BRL";
                                                                    tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                                                    valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                                                    inputmontoenviar.value=valtotalrecibe;
                                                                    numcomision.innerHTML=valcomision+"% : &nbsp;";
                                                                    tcambio.value=valrealausd;
                                                                    tcomisi.value=valcomenviar;
                                                                    timpues.value=valimpuestos;
                                                                    ttotale.value=valtotalenviar;
                                                                    tenviar.value=resultadoinicial;//modificar
                                                                    trecibe.value=valtotalrecibe;
                                                                    tmoneda.value='Dolar a Real';
                                                                    btnsiguiente.style.display='block';
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            //termina
                                        }else{
                                            comision=co3000a5000brlausd.value;
                                            inversa=in3000a5000brlausd.value;
                                            //inversa=in1000a5000brlusd;
                                            //comision=comision1000a5000.value;
                                            //inversa=inversacomision1000a5000.value;
                                            errorenvio.style.display='none';
                                            valcomision=(parseFloat(comision)*100).toFixed(2);
                                            resultadoinicial=(((parseFloat(valmonto)/inversa))/parseFloat(valrealausd)).toFixed(2);//modificar
                                            valcomenviar=(parseFloat(resultadoinicial)*parseFloat(comision)).toFixed(2);//modificar
                                            valimpuestos=(parseFloat(impuesto)*parseFloat(valcomenviar)).toFixed(2);
                                            valtotalcomimp=parseFloat(valcomenviar)+parseFloat(valimpuestos);
                                            valtotalenviar=(parseFloat(resultadoinicial)-parseFloat(valtotalcomimp)).toFixed(2);//modificar
                                            tipodeimpuestos.innerHTML=valimpuestos+"&nbsp;BRL";
                                            tipodecambio.innerHTML=valrealausd;
                                            tipodecomision.innerHTML=+valcomenviar+" BRL";
                                            tipototalenviar.innerHTML=valtotalenviar+"&nbsp;BRL";
                                            valtotalrecibe=parseFloat(resultadoinicial).toFixed(2);//modificar
                                            inputmontoenviar.value=valtotalrecibe;
                                            numcomision.innerHTML=valcomision+"% : &nbsp;";
                                            tcambio.value=valrealausd;
                                            tcomisi.value=valcomenviar;
                                            timpues.value=valimpuestos;
                                            ttotale.value=valtotalenviar;
                                            tenviar.value=resultadoinicial;//modificar
                                            trecibe.value=valtotalrecibe;
                                            tmoneda.value='Dolar a Real';
                                            btnsiguiente.style.display='block';
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                break;
        }
        //alert(valeletipmonenv);
    },
    mostrar:function(){
        btnsiguientese.style.display='block';
    }
}
</script>