<div class="bgazulcorporativo centro">
    <div class="centro">
        <div style="height:30px;"></div>
        <div class="flex">
            <div class="centro txtcentro fontbebas txt30 txtblanco" style="padding:10px;width:60%">
                Si desea enviar dinero de Brasil a Perú o de Perú a Brasil, comuníquese con nosotros.
                ¡Compare, pruebe y disfrute nuestro excelente servicio!
            </div>
            <div class="centro" style="width:40%;">
                <center>
                    <img src="{{url_for('static',filename='img/braspermapa2.png')}}" class="imgmapa">
                </center>
            </div>
        </div>
        <div style="height:30px;"></div>
    </div>
</div>